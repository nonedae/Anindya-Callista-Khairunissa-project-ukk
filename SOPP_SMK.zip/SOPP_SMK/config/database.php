<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_sopp_smkn1dlanggu');

// Application settings
define('APP_NAME', 'Sistem Pembayaran SOPP');
define('APP_VERSION', '1.0');
define('SOPP_BIAYA', 200000); // Rp 200.000 per bulan

// Create connection
function koneksiDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Koneksi database gagal: " . $conn->connect_error);
    }
    
    return $conn;
}

// Redirect function
function redirect($url) {
    // Fix path untuk redirect
    if (strpos($url, '../') === 0) {
        header("Location: $url");
    } else {
        header("Location: $url");
    }
    exit();
}

// Check if user is logged in
function sudahLogin() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check role - PERBAIKAN UTAMA
function cekRole($role_diizinkan) {
    // Cek apakah user sudah login
    if (!sudahLogin()) {
        $_SESSION['error'] = 'Silakan login terlebih dahulu!';
        
        // Hitung jumlah folder untuk kembali ke root
        $path = '';
        $depth = substr_count($_SERVER['SCRIPT_NAME'], '/') - 1;
        for ($i = 0; $i < $depth; $i++) {
            $path .= '../';
        }
        redirect($path . 'login.php');
    }
    
    // Cek apakah role user ada di session
    if (!isset($_SESSION['role'])) {
        session_destroy();
        $_SESSION['error'] = 'Session tidak valid! Silakan login ulang.';
        redirect('../login.php');
    }
    
    // Cek apakah role user diizinkan
    if (!in_array($_SESSION['role'], $role_diizinkan)) {
        $_SESSION['error'] = 'Akses ditolak! Anda tidak memiliki hak akses ke halaman ini.';
        
        // Redirect berdasarkan role
        switch ($_SESSION['role']) {
            case 'admin':
                redirect('../admin/dashboard.php');
                break;
            case 'wali_kelas':
                redirect('../wali/dashboard.php');
                break;
            case 'siswa':
                redirect('../siswa/dashboard.php');
                break;
            default:
                redirect('../login.php');
        }
    }
    
    return true;
}

// Format currency
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Get bulan list
function getBulanList() {
    return [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
}

// Get tahun list
function getTahunList() {
    $tahun_sekarang = date('Y');
    $tahun = [];
    for ($i = $tahun_sekarang - 2; $i <= $tahun_sekarang + 2; $i++) {
        $tahun[] = $i;
    }
    return $tahun;
}

// Format tanggal Indonesia - DIPERBAIKI
function formatTanggalIndo($tanggal) {
    if (empty($tanggal) || $tanggal == '0000-00-00') {
        return '-';
    }
    
    $bulan = array(
        1 => 'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    
    $pecah = explode('-', $tanggal);
    
    // Validasi array
    if (count($pecah) < 3) {
        return $tanggal;
    }
    
    $bulan_index = (int)$pecah[1];
    if ($bulan_index < 1 || $bulan_index > 12) {
        return $tanggal;
    }
    
    return $pecah[2] . ' ' . $bulan[$bulan_index] . ' ' . $pecah[0];
}

// Generate nomor kwitansi
function generateNoKwitansi() {
    $tahun = date('Y');
    $bulan = date('m');
    $hari = date('d');
    $random = mt_rand(1000, 9999);
    return "KW/{$tahun}{$bulan}{$hari}/{$random}";
}

// Terbilang angka ke kata
function terbilang($angka) {
    $angka = abs($angka);
    $baca = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    
    $terbilang = "";
    if ($angka < 12) {
        $terbilang = " " . $baca[$angka];
    } else if ($angka < 20) {
        $terbilang = terbilang($angka - 10) . " belas";
    } else if ($angka < 100) {
        $terbilang = terbilang($angka / 10) . " puluh" . terbilang($angka % 10);
    } else if ($angka < 200) {
        $terbilang = " seratus" . terbilang($angka - 100);
    } else if ($angka < 1000) {
        $terbilang = terbilang($angka / 100) . " ratus" . terbilang($angka % 100);
    } else if ($angka < 2000) {
        $terbilang = " seribu" . terbilang($angka - 1000);
    } else if ($angka < 1000000) {
        $terbilang = terbilang($angka / 1000) . " ribu" . terbilang($angka % 1000);
    } else if ($angka < 1000000000) {
        $terbilang = terbilang($angka / 1000000) . " juta" . terbilang($angka % 1000000);
    }
    
    return trim($terbilang);
}

// Format terbilang rupiah
function formatTerbilangRupiah($angka) {
    $terbilang = terbilang($angka);
    return ucfirst($terbilang) . " rupiah";
}

// Fungsi untuk menampilkan pesan error dari session
function tampilkanPesan() {
    if (isset($_SESSION['error'])) {
        $pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>' . $_SESSION['error'] . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
        unset($_SESSION['error']);
        return $pesan;
    }
    
    if (isset($_SESSION['success'])) {
        $pesan = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i>' . $_SESSION['success'] . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
        unset($_SESSION['success']);
        return $pesan;
    }
    
    return '';
}

// Debug function - HAPUS ATAU KOMENTAR SAAT PRODUCTION
function debug_session() {
    echo '<div style="background: #f8d7da; padding: 10px; margin: 10px; border: 1px solid #f5c6cb; border-radius: 5px;">';
    echo '<strong>DEBUG SESSION:</strong><br>';
    echo 'User ID: ' . ($_SESSION['user_id'] ?? 'Tidak ada') . '<br>';
    echo 'Username: ' . ($_SESSION['username'] ?? 'Tidak ada') . '<br>';
    echo 'Role: ' . ($_SESSION['role'] ?? 'Tidak ada') . '<br>';
    echo 'Script: ' . $_SERVER['SCRIPT_NAME'] . '<br>';
    echo '</div>';
}
?>