<?php
// Konfigurasi Duitku
define('DUITKU_MERCHANT_CODE', 'YOUR_MERCHANT_CODE'); // Ganti dengan kode merchant Anda
define('DUITKU_API_KEY', 'YOUR_API_KEY'); // Ganti dengan API key Anda
define('DUITKU_SANDBOX', true); // Ubah ke false untuk production

/**
 * Dapatkan metode pembayaran yang tersedia
 */
function getPaymentMethods() {
    return [
        'va_bca' => [
            'title' => 'Transfer BCA',
            'icon' => 'bi-bank',
            'desc' => 'Virtual Account BCA'
        ],
        'va_mandiri' => [
            'title' => 'Transfer Mandiri',
            'icon' => 'bi-bank2',
            'desc' => 'Virtual Account Mandiri'
        ],
        'va_bni' => [
            'title' => 'Transfer BNI',
            'icon' => 'bi-bank',
            'desc' => 'Virtual Account BNI'
        ],
        'va_bri' => [
            'title' => 'Transfer BRI',
            'icon' => 'bi-bank2',
            'desc' => 'Virtual Account BRI'
        ],
        'qris' => [
            'title' => 'QRIS',
            'icon' => 'bi-qr-code-scan',
            'desc' => 'Scan QRIS (Ovo, Gopay, Dana)'
        ],
        'alfamart' => [
            'title' => 'Alfamart',
            'icon' => 'bi-shop',
            'desc' => 'Pembayaran di Alfamart'
        ],
        'indomaret' => [
            'title' => 'Indomaret',
            'icon' => 'bi-shop',
            'desc' => 'Pembayaran di Indomaret'
        ]
    ];
}

/**
 * Generate Order ID
 */
function generateOrderId(, , ) {
    return 'SOPP-' .  . '-' . time() . '-' . rand(100, 999);
}

/**
 * Dapatkan URL pembayaran dari Duitku
 */
function getDuitkuPaymentUrl() {
    // Untuk sementara, return dummy response
    return [
        'success' => true,
        'payment_url' => '#',
        'message' => 'Pembayaran akan diproses (Mode Development)'
    ];
}

/**
 * Format Rupiah
 */
function formatRupiah() {
    return 'Rp ' . number_format(, 0, ',', '.');
}

/**
 * Dapatkan daftar bulan
 */
function getBulanList() {
    return ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
}

/**
 * Dapatkan daftar tahun
 */
function getTahunList() {
     = date('Y');
    return [,  + 1];
}
