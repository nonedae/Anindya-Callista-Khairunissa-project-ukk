<?php
require_once 'database.php';

// Function untuk generate kwitansi number
function generateNoKwitansi() {
    $tahun = date('Y');
    $bulan = date('m');
    $random = mt_rand(1000, 9999);
    return "KW/{$tahun}/{$bulan}/{$random}";
}

// Function untuk cek duplikat pembayaran
function cekDuplikatPembayaran($id_siswa, $bulan, $tahun) {
    $conn = koneksiDB();
    $stmt = $conn->prepare("SELECT id_pembayaran FROM pembayaran WHERE id_siswa = ? AND bulan = ? AND tahun = ?");
    $stmt->bind_param("iss", $id_siswa, $bulan, $tahun);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->num_rows > 0;
    $stmt->close();
    $conn->close();
    return $exists;
}

// Function untuk format tanggal Indonesia
function formatTanggalIndo($tanggal) {
    if (empty($tanggal) || $tanggal == '0000-00-00') {
        return '-';
    }
    
    $bulan = array(
        1 => 'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    
    $pecah = explode('-', $tanggal);
    $tahun = $pecah[0];
    $bln = (int)$pecah[1];
    $hari = $pecah[2];
    
    return $hari . ' ' . $bulan[$bln] . ' ' . $tahun;
}

// Function untuk get nama hari
function getHariIndo($tanggal) {
    $hari = array(
        'Sunday' => 'Minggu',
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu'
    );
    $day = date('l', strtotime($tanggal));
    return isset($hari[$day]) ? $hari[$day] : $day;
}

// Function untuk terbilang rupiah
function terbilang($angka) {
    $angka = abs($angka);
    $baca = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    
    $terbilang = "";
    if ($angka < 12) {
        $terbilang = " " . $baca[$angka];
    } else if ($angka < 20) {
        $terbilang = terbilang($angka - 10) . " belas";
    } else if ($angka < 100) {
        $terbilang = terbilang($angka / 10) . " puluh" . terbilang($angka % 10);
    } else if ($angka < 200) {
        $terbilang = " seratus" . terbilang($angka - 100);
    } else if ($angka < 1000) {
        $terbilang = terbilang($angka / 100) . " ratus" . terbilang($angka % 100);
    } else if ($angka < 2000) {
        $terbilang = " seribu" . terbilang($angka - 1000);
    } else if ($angka < 1000000) {
        $terbilang = terbilang($angka / 1000) . " ribu" . terbilang($angka % 1000);
    } else if ($angka < 1000000000) {
        $terbilang = terbilang($angka / 1000000) . " juta" . terbilang($angka % 1000000);
    }
    
    return trim($terbilang);
}

// Function untuk format terbilang rupiah
function formatTerbilangRupiah($angka) {
    $terbilang = terbilang($angka);
    return ucfirst($terbilang) . " rupiah";
}

// Function untuk validasi NISN (10 digit)
function validasiNISN($nisn) {
    return preg_match('/^\d{10}$/', $nisn);
}

// Function untuk validasi NIP (18-20 digit)
function validasiNIP($nip) {
    return preg_match('/^\d{18,20}$/', $nip);
}

// Function untuk menghitung usia dari tanggal lahir
function hitungUsia($tanggal_lahir) {
    if (empty($tanggal_lahir) || $tanggal_lahir == '0000-00-00') {
        return '-';
    }
    
    $tanggal = new DateTime($tanggal_lahir);
    $sekarang = new DateTime('today');
    $usia = $sekarang->diff($tanggal)->y;
    
    return $usia . ' tahun';
}

// Function untuk mendapatkan status pembayaran
function getStatusPembayaran($bulan, $tahun) {
    $bulan_sekarang = date('n');
    $tahun_sekarang = date('Y');
    
    // Cek apakah bulan ini atau sudah lewat
    if ($tahun < $tahun_sekarang || ($tahun == $tahun_sekarang && array_search($bulan, getBulanList()) + 1 < $bulan_sekarang)) {
        return 'telat';
    } elseif ($tahun == $tahun_sekarang && array_search($bulan, getBulanList()) + 1 == $bulan_sekarang) {
        return 'bulan_ini';
    } else {
        return 'mendatang';
    }
}
?>