<?php
require_once '../config/database.php';
cekRole(['wali_kelas']);

$conn = koneksiDB();
$user_id = $_SESSION['user_id'];

// Get guru/wali kelas data
$guru = $conn->query("
    SELECT g.*, wk.id_kelas, wk.tahun_ajaran, k.nama_kelas 
    FROM guru g 
    LEFT JOIN wali_kelas wk ON g.id_guru = wk.id_guru 
    LEFT JOIN kelas k ON wk.id_kelas = k.id_kelas 
    WHERE g.user_id = $user_id
")->fetch_assoc();

if (!$guru || !$guru['id_kelas']) {
    die("<script>
        alert('❌ Anda belum ditugaskan sebagai wali kelas!');
        window.location.href = '../login.php';
    </script>");
}

$id_kelas = $guru['id_kelas'];
$tahun_ajaran = $guru['tahun_ajaran'] ?? (date('Y') . '/' . (date('Y')+1));

// Get statistics
$total_siswa = $conn->query("SELECT COUNT(*) as total FROM siswa WHERE id_kelas = $id_kelas")->fetch_assoc()['total'];

// Pembayaran bulan ini
$bulan_ini = date('m');
$tahun_ini = date('Y');
$bulan_ini_nama = date('F');
$bulan_indonesia = [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
];
$bulan_ini_indonesia = $bulan_indonesia[$bulan_ini_nama];

// Sudah bayar bulan ini
$sudah_bayar = $conn->query("
    SELECT COUNT(DISTINCT p.id_siswa) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas 
    AND p.bulan = '$bulan_ini_indonesia' 
    AND p.tahun = '$tahun_ini'
")->fetch_assoc()['total'] ?? 0;

$belum_bayar = $total_siswa - $sudah_bayar;

// Siswa belum bayar bulan ini
$siswa_belum_bayar = $conn->query("
    SELECT s.* 
    FROM siswa s 
    WHERE s.id_kelas = $id_kelas 
    AND s.id_siswa NOT IN (
        SELECT p.id_siswa FROM pembayaran p 
        WHERE p.bulan = '$bulan_ini_indonesia' 
        AND p.tahun = '$tahun_ini'
    )
    ORDER BY s.nama_siswa
    LIMIT 10
");

// Riwayat pembayaran kelas
$riwayat_kelas = $conn->query("
    SELECT 
        p.bulan, 
        p.tahun, 
        COUNT(DISTINCT p.id_siswa) as jumlah_siswa, 
        SUM(p.jumlah) as total
    FROM pembayaran p
    JOIN siswa s ON p.id_siswa = s.id_siswa
    WHERE s.id_kelas = $id_kelas
    GROUP BY p.bulan, p.tahun
    ORDER BY p.tahun DESC, FIELD(p.bulan, 
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ) DESC
    LIMIT 6
");

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Wali Kelas - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .navbar-brand, .navbar .text-white {
            color: white !important;
        }
        .navbar .btn-outline-light {
            border-color: rgba(255,255,255,0.5);
            color: white;
        }
        .navbar .btn-outline-light:hover {
            background: white;
            color: #667eea;
        }
        .badge-wali {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 500;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 20px;
        }
        .card:hover {
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        }
        .stat-card {
            border-radius: 15px;
            padding: 25px;
            color: white;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .stat-card-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .stat-card-warning { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-card-info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        
        .menu-card {
            text-align: center;
            padding: 30px 20px;
            border-radius: 15px;
            background: white;
            transition: all 0.3s;
            height: 100%;
            text-decoration: none;
            color: #495057;
            display: block;
            border: 1px solid rgba(0,0,0,0.05);
        }
        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .menu-card i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #667eea;
        }
        .menu-card:hover i {
            color: white;
        }
        .table th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
        .class-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <i class="bi bi-cash-coin fs-3 me-2"></i>
                <div>
                    <span class="fw-bold fs-5">SOPP</span>
                    <br>
                    <small>SMKN 1 DLANGGU</small>
                </div>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="badge-wali me-3">
                    <i class="bi bi-person-badge"></i> 
                    <strong><?php echo htmlspecialchars($guru['nama_guru']); ?></strong>
                </span>
                <span class="badge bg-light text-dark me-3">
                    <i class="bi bi-door-open"></i> <?php echo htmlspecialchars($guru['nama_kelas']); ?>
                </span>
                <a href="../logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- HEADER KELAS -->
        <div class="class-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="fw-bold mb-2">Dashboard Wali Kelas</h2>
                    <h3 class="mb-2"><?php echo htmlspecialchars($guru['nama_kelas']); ?></h3>
                    <p class="mb-0 opacity-75">
                        <i class="bi bi-person"></i> Wali Kelas: <strong><?php echo htmlspecialchars($guru['nama_guru']); ?></strong> 
                        | <i class="bi bi-calendar"></i> Tahun Ajaran: <?php echo $tahun_ajaran; ?>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <i class="bi bi-person-check display-1 opacity-25"></i>
                </div>
            </div>
        </div>
        
        <!-- STATISTIK CARD -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Total Siswa</h6>
                            <h2 class="display-6 text-white mb-0 fw-bold"><?php echo $total_siswa; ?></h2>
                            <small class="text-white-50">Orang</small>
                        </div>
                        <i class="bi bi-people-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card stat-card stat-card-success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Sudah Bayar</h6>
                            <h2 class="display-6 text-white mb-0 fw-bold"><?php echo $sudah_bayar; ?></h2>
                            <small class="text-white-50">Siswa</small>
                        </div>
                        <i class="bi bi-check-circle-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card stat-card stat-card-warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Belum Bayar</h6>
                            <h2 class="display-6 text-white mb-0 fw-bold"><?php echo $belum_bayar; ?></h2>
                            <small class="text-white-50">Siswa</small>
                        </div>
                        <i class="bi bi-x-circle-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- MENU CEPAT (FIXED: LINK LAPORAN KE WALI/LAPORAN.PHP) -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <a href="siswa.php" class="menu-card">
                    <i class="bi bi-people-fill"></i>
                    <h5 class="fw-bold">Data Siswa</h5>
                    <p class="mb-0 small opacity-75">Lihat daftar siswa</p>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <a href="pembayaran.php" class="menu-card">
                    <i class="bi bi-cash-coin"></i>
                    <h5 class="fw-bold">Pembayaran</h5>
                    <p class="mb-0 small opacity-75">Riwayat pembayaran</p>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <!-- ✅ FIXED: Arahkan ke wali/laporan.php, BUKAN admin/laporan.php -->
                <a href="laporan.php" class="menu-card">
                    <i class="bi bi-file-text"></i>
                    <h5 class="fw-bold">Laporan</h5>
                    <p class="mb-0 small opacity-75">Cetak laporan kelas</p>
                </a>
            </div>
        </div>
        
        <!-- KONTEN DETAIL -->
        <div class="row">
            <!-- SISWA BELUM BAYAR BULAN INI -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-warning text-dark bg-opacity-25">
                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            Belum Bayar Bulan <?php echo $bulan_ini_indonesia . ' ' . $tahun_ini; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if ($siswa_belum_bayar && $siswa_belum_bayar->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-sm">
                                    <thead class="table-light">
                                        <tr>
                                            <th>No</th>
                                            <th>NISN</th>
                                            <th>Nama Siswa</th>
                                            <th>Kelas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php while($siswa = $siswa_belum_bayar->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $siswa['nisn']; ?></td>
                                            <td class="fw-bold"><?php echo $siswa['nama_siswa']; ?></td>
                                            <td><?php echo $guru['nama_kelas']; ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-end mt-2">
                                <span class="badge bg-warning text-dark">
                                    Total: <?php echo $siswa_belum_bayar->num_rows; ?> siswa
                                </span>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <div class="display-1 text-success mb-3">
                                    <i class="bi bi-check-circle-fill"></i>
                                </div>
                                <h5 class="text-success">Semua siswa sudah membayar!</h5>
                                <p class="text-muted mb-0">Bulan <?php echo $bulan_ini_indonesia . ' ' . $tahun_ini; ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- RIWAYAT PEMBAYARAN -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-clock-history me-2"></i>
                            Riwayat Pembayaran Kelas
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if ($riwayat_kelas && $riwayat_kelas->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Bulan/Tahun</th>
                                            <th class="text-center">Jumlah Siswa</th>
                                            <th class="text-end">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($row = $riwayat_kelas->fetch_assoc()): ?>
                                        <tr>
                                            <td class="fw-bold"><?php echo $row['bulan'] . ' ' . $row['tahun']; ?></td>
                                            <td class="text-center">
                                                <span class="badge bg-info"><?php echo $row['jumlah_siswa']; ?> siswa</span>
                                            </td>
                                            <td class="text-end fw-bold text-success">
                                                <?php echo formatRupiah($row['total']); ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-end mt-2">
                                <a href="laporan.php" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-file-text"></i> Lihat Laporan Lengkap
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <div class="display-1 text-muted mb-3">
                                    <i class="bi bi-cash-coin"></i>
                                </div>
                                <h5 class="text-muted">Belum ada riwayat pembayaran</h5>
                                <p class="text-muted">Siswa di kelas Anda belum melakukan pembayaran</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- INFORMASI TAMBAHAN -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5 class="text-primary">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            Informasi Wali Kelas
                        </h5>
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                Anda adalah wali kelas <strong><?php echo $guru['nama_kelas']; ?></strong>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                Hanya bisa melihat data siswa di kelas Anda
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                Bisa melihat riwayat pembayaran siswa
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                Bisa mencetak laporan pembayaran kelas
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="bg-light p-3 rounded">
                            <small class="text-muted d-block">Biaya SOPP</small>
                            <h4 class="text-primary fw-bold mb-0"><?php echo formatRupiah(SOPP_BIAYA); ?></h4>
                            <small class="text-muted">per bulan</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>