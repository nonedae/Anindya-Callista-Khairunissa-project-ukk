<?php
require_once '../config/database.php';
cekRole(['wali_kelas']);

$conn = koneksiDB();
$user_id = $_SESSION['user_id'];

// Get guru/wali kelas data
$guru = $conn->query("
    SELECT g.*, wk.id_kelas, wk.tahun_ajaran, k.nama_kelas 
    FROM guru g 
    LEFT JOIN wali_kelas wk ON g.id_guru = wk.id_guru 
    LEFT JOIN kelas k ON wk.id_kelas = k.id_kelas 
    WHERE g.user_id = $user_id
")->fetch_assoc();

if (!$guru || !$guru['id_kelas']) {
    die("<script>
        alert('❌ Anda belum ditugaskan sebagai wali kelas!');
        window.location.href = 'dashboard.php';
    </script>");
}

$id_kelas = $guru['id_kelas'];
$tahun_ajaran = $guru['tahun_ajaran'] ?? (date('Y') . '/' . (date('Y')+1));

// ================ FILTER ================
$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : '';
$filter_tahun = isset($_GET['filter_tahun']) ? $_GET['filter_tahun'] : date('Y');
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : 'semua';

// ================ BULAN LIST ================
$bulan_list = getBulanList();

// ================ GET ALL SISWA IN CLASS ================
$siswa = $conn->query("
    SELECT * FROM siswa 
    WHERE id_kelas = $id_kelas 
    ORDER BY nama_siswa
");

// ================ GET PAYMENTS PER SISWA ================
$pembayaran_siswa = [];
$total_sudah_bayar = 0;
$total_belum_bayar = 0;
$total_nominal_bayar = 0;

while($row = $siswa->fetch_assoc()) {
    $id_siswa = $row['id_siswa'];
    
    // Get payments for this student
    $payments = $conn->query("
        SELECT * FROM pembayaran 
        WHERE id_siswa = $id_siswa
    ");
    
    $sudah_bayar = [];
    while($p = $payments->fetch_assoc()) {
        $sudah_bayar[$p['bulan'] . '-' . $p['tahun']] = $p;
        $total_nominal_bayar += $p['jumlah'];
    }
    
    $pembayaran_siswa[$id_siswa] = [
        'data' => $row,
        'sudah_bayar' => $sudah_bayar
    ];
    
    // Hitung status bayar per bulan
    foreach($bulan_list as $bulan) {
        $key = $bulan . '-' . $filter_tahun;
        if (isset($sudah_bayar[$key])) {
            $total_sudah_bayar++;
        } else {
            if ($filter_bulan == '' || $filter_bulan == $bulan) {
                $total_belum_bayar++;
            }
        }
    }
}

// ================ GET PAYMENTS WITH FILTER ================
$sql_payments = "
    SELECT p.*, s.nama_siswa, s.nisn 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
";

if (!empty($filter_bulan)) {
    $sql_payments .= " AND p.bulan = '$filter_bulan'";
}

if (!empty($filter_tahun)) {
    $sql_payments .= " AND p.tahun = '$filter_tahun'";
}

$sql_payments .= " ORDER BY p.tanggal_bayar DESC";
$riwayat_pembayaran = $conn->query($sql_payments);

// ================ STATISTIK ================
$total_siswa = $conn->query("SELECT COUNT(*) as total FROM siswa WHERE id_kelas = $id_kelas")->fetch_assoc()['total'];
$total_transaksi = $conn->query("
    SELECT COUNT(*) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
")->fetch_assoc()['total'];
$total_dana = $conn->query("
    SELECT SUM(p.jumlah) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
")->fetch_assoc()['total'] ?? 0;

// ================ BELUM BAYAR BULAN INI ================
$bulan_ini = date('F');
$tahun_ini = date('Y');
$bulan_ini_indonesia = [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
];
$bulan_ini_indonesia = $bulan_ini_indonesia[$bulan_ini];

$siswa_belum_bayar_bulan_ini = $conn->query("
    SELECT s.* 
    FROM siswa s 
    WHERE s.id_kelas = $id_kelas 
    AND s.id_siswa NOT IN (
        SELECT p.id_siswa 
        FROM pembayaran p 
        WHERE p.bulan = '$bulan_ini_indonesia' AND p.tahun = '$tahun_ini'
    )
    ORDER BY s.nama_siswa
");

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kelas - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .navbar-brand, .navbar .text-white {
            color: white !important;
        }
        .badge-wali {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 500;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        .card-header {
            background: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            border-radius: 15px 15px 0 0 !important;
            padding: 1.2rem 1.5rem;
            font-weight: 600;
        }
        .stat-card {
            border-radius: 15px;
            padding: 20px;
            color: white;
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-card-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .stat-card-warning { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-card-info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        
        .table th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            color: #495057;
            font-weight: 600;
        }
        .badge-bayar {
            background: #d4edda;
            color: #155724;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-belum {
            background: #f8d7da;
            color: #721c24;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .filter-box {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .btn-print {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 10px;
            padding: 8px 20px;
            font-weight: 600;
        }
        .btn-print:hover {
            background: #667eea;
            color: white;
        }
        .month-cell {
            text-align: center;
            padding: 8px !important;
            vertical-align: middle;
        }
        .print-only {
            display: none;
        }
        @media print {
            .no-print { display: none; }
            .print-only { display: block; }
            .card { box-shadow: none; border: 1px solid #ddd; }
            body { background: white; }
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm no-print">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <i class="bi bi-cash-coin fs-3 me-2"></i>
                <div>
                    <span class="fw-bold fs-5">SOPP</span>
                    <br>
                    <small>SMKN 1 DLANGGU</small>
                </div>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="badge-wali me-3">
                    <i class="bi bi-person-badge"></i> 
                    <strong><?php echo htmlspecialchars($guru['nama_guru']); ?></strong>
                </span>
                <span class="badge bg-light text-dark me-3">
                    <i class="bi bi-door-open"></i> Kelas <?php echo htmlspecialchars($guru['nama_kelas']); ?>
                </span>
                <a href="dashboard.php" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-arrow-left"></i> Dashboard
                </a>
                <a href="../logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4 no-print">
            <div>
                <h3 class="fw-bold text-primary mb-1">
                    <i class="bi bi-file-text"></i> Laporan Pembayaran SOPP
                </h3>
                <p class="text-muted mb-0">
                    <i class="bi bi-door-open"></i> Kelas <?php echo htmlspecialchars($guru['nama_kelas']); ?> | 
                    Wali Kelas: <?php echo htmlspecialchars($guru['nama_guru']); ?> |
                    Tahun Ajaran: <?php echo $tahun_ajaran; ?>
                </p>
            </div>
            <div>
                <button onclick="window.print()" class="btn btn-print me-2">
                    <i class="bi bi-printer"></i> Cetak Laporan
                </button>
                <a href="pembayaran.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <!-- PRINT HEADER (ONLY SHOW WHEN PRINT) -->
        <div class="print-only mb-4">
            <div style="text-align: center; margin-bottom: 30px;">
                <h2 style="margin-bottom: 5px;">SMKN 1 DLANGGU</h2>
                <h4 style="margin-bottom: 5px;">Sistem Pembayaran SOPP</h4>
                <p style="margin-bottom: 5px;">Jl. A. Yani No 01, Ds. Pohkecik, Mojokerto</p>
                <hr style="border-top: 2px solid #000; margin: 20px 0;">
                <h3>LAPORAN PEMBAYARAN SOPP</h3>
                <table style="width: 100%; margin-top: 20px;">
                    <tr>
                        <td style="width: 20%;"><strong>Kelas</strong></td>
                        <td style="width: 5%;">:</td>
                        <td style="width: 75%;"><?php echo $guru['nama_kelas']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Wali Kelas</strong></td>
                        <td>:</td>
                        <td><?php echo $guru['nama_guru']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tahun Ajaran</strong></td>
                        <td>:</td>
                        <td><?php echo $tahun_ajaran; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Cetak</strong></td>
                        <td>:</td>
                        <td><?php echo date('d F Y'); ?></td>
                    </tr>
                </table>
                <hr style="border-top: 1px solid #000; margin: 20px 0;">
            </div>
        </div>
        
        <!-- STATISTIK CARD -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="stat-card stat-card-primary">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Total Siswa</h6>
                            <h2 class="display-6 mb-0"><?php echo $total_siswa; ?></h2>
                            <small>Orang</small>
                        </div>
                        <i class="bi bi-people-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="stat-card stat-card-success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Sudah Bayar</h6>
                            <h2 class="display-6 mb-0"><?php echo $total_sudah_bayar; ?></h2>
                            <small>Transaksi</small>
                        </div>
                        <i class="bi bi-check-circle-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="stat-card stat-card-warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Belum Bayar</h6>
                            <h2 class="display-6 mb-0"><?php echo $total_belum_bayar; ?></h2>
                            <small>Kali</small>
                        </div>
                        <i class="bi bi-x-circle-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="stat-card stat-card-info">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50 mb-2">Total Dana</h6>
                            <h5 class="mb-0"><?php echo formatRupiah($total_dana); ?></h5>
                            <small>Terkumpul</small>
                        </div>
                        <i class="bi bi-cash-stack fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FILTER SECTION (NO PRINT) -->
        <div class="card no-print">
            <div class="card-header">
                <i class="bi bi-funnel me-2"></i> Filter Laporan
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Filter Bulan</label>
                        <select class="form-select" name="filter_bulan">
                            <option value="">-- Semua Bulan --</option>
                            <?php foreach($bulan_list as $bulan): ?>
                            <option value="<?php echo $bulan; ?>" <?php echo $filter_bulan == $bulan ? 'selected' : ''; ?>>
                                <?php echo $bulan; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Filter Tahun</label>
                        <select class="form-select" name="filter_tahun">
                            <?php 
                            $tahun_mulai = date('Y') - 2;
                            $tahun_akhir = date('Y') + 2;
                            for($t = $tahun_mulai; $t <= $tahun_akhir; $t++): 
                            ?>
                            <option value="<?php echo $t; ?>" <?php echo $filter_tahun == $t ? 'selected' : ''; ?>>
                                <?php echo $t; ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Filter Status</label>
                        <select class="form-select" name="filter_status">
                            <option value="semua" <?php echo $filter_status == 'semua' ? 'selected' : ''; ?>>Semua Siswa</option>
                            <option value="sudah" <?php echo $filter_status == 'sudah' ? 'selected' : ''; ?>>Sudah Bayar</option>
                            <option value="belum" <?php echo $filter_status == 'belum' ? 'selected' : ''; ?>>Belum Bayar</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label fw-bold">&nbsp;</label>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-filter"></i> Terapkan
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- SISWA BELUM BAYAR BULAN INI -->
        <div class="card">
            <div class="card-header bg-warning text-dark">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> 
                Belum Bayar Bulan <?php echo $bulan_ini_indonesia . ' ' . $tahun_ini; ?>
            </div>
            <div class="card-body">
                <?php if ($siswa_belum_bayar_bulan_ini->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NISN</th>
                                    <th>Nama Siswa</th>
                                    <th>Telepon</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php while($row = $siswa_belum_bayar_bulan_ini->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $row['nisn']; ?></td>
                                    <td><?php echo $row['nama_siswa']; ?></td>
                                    <td><?php echo $row['no_telp'] ?? '-'; ?></td>
                                    <td><span class="badge bg-danger">Belum Bayar</span></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="bi bi-check-circle-fill text-success fs-1"></i>
                        <h5 class="mt-2 text-success">Semua siswa sudah membayar bulan <?php echo $bulan_ini_indonesia . ' ' . $tahun_ini; ?>!</h5>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- REKAP PEMBAYARAN PER SISWA -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-table me-2"></i> Rekap Pembayaran Siswa - Tahun <?php echo $filter_tahun; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th rowspan="2" style="vertical-align: middle; text-align: center;">No</th>
                                <th rowspan="2" style="vertical-align: middle;">NISN</th>
                                <th rowspan="2" style="vertical-align: middle;">Nama Siswa</th>
                                <th colspan="12" style="text-align: center;">Bulan Pembayaran <?php echo $filter_tahun; ?></th>
                                <th rowspan="2" style="vertical-align: middle; text-align: center;">Total</th>
                            </tr>
                            <tr>
                                <?php 
                                $bulan_singkat = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
                                foreach($bulan_singkat as $b): 
                                ?>
                                <th style="text-align: center; width: 45px;"><?php echo $b; ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            $grand_total = 0;
                            foreach($pembayaran_siswa as $id_siswa => $data): 
                                $siswa_data = $data['data'];
                                $sudah_bayar = $data['sudah_bayar'];
                                $total_siswa_bayar = 0;
                            ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $no++; ?></td>
                                <td><?php echo $siswa_data['nisn']; ?></td>
                                <td><?php echo $siswa_data['nama_siswa']; ?></td>
                                
                                <?php foreach($bulan_list as $bulan): ?>
                                    <?php 
                                    $key = $bulan . '-' . $filter_tahun;
                                    if (isset($sudah_bayar[$key])): 
                                        $total_siswa_bayar++;
                                        $grand_total++;
                                    ?>
                                    <td style="text-align: center; background: #d4edda;">
                                        <i class="bi bi-check-lg text-success"></i>
                                    </td>
                                    <?php else: ?>
                                    <td style="text-align: center; background: #f8d7da;">
                                        <i class="bi bi-x-lg text-danger"></i>
                                    </td>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo $total_siswa_bayar; ?> / 12
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <th colspan="3" style="text-align: right;">Total Pembayaran:</th>
                                <th colspan="12" style="text-align: center;"><?php echo $grand_total; ?> Bulan</th>
                                <th style="text-align: center;">-</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- RIWAYAT PEMBAYARAN -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <i class="bi bi-clock-history me-2"></i> Riwayat Pembayaran
                <?php if (!empty($filter_bulan) || !empty($filter_tahun)): ?>
                    <span class="badge bg-light text-dark ms-2">
                        Filter: <?php echo $filter_bulan ?: 'Semua Bulan'; ?> <?php echo $filter_tahun; ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nama Siswa</th>
                                <th>NISN</th>
                                <th>Bulan/Tahun</th>
                                <th>Jumlah</th>
                                <th>No. Kwitansi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($riwayat_pembayaran && $riwayat_pembayaran->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $riwayat_pembayaran->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['tanggal_bayar'])); ?></td>
                                    <td><?php echo $row['nama_siswa']; ?></td>
                                    <td><?php echo $row['nisn']; ?></td>
                                    <td><?php echo $row['bulan'] . ' ' . $row['tahun']; ?></td>
                                    <td class="fw-bold text-success"><?php echo formatRupiah($row['jumlah']); ?></td>
                                    <td><small><?php echo $row['no_kwitansi']; ?></small></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <i class="bi bi-cash-coin display-4 text-muted"></i>
                                        <h5 class="mt-3">Belum ada riwayat pembayaran</h5>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- FOOTER (PRINT ONLY) -->
        <div class="print-only" style="margin-top: 50px;">
            <table style="width: 100%;">
                <tr>
                    <td style="width: 60%;"></td>
                    <td style="width: 40%; text-align: center;">
                        <p>Mojokerto, <?php echo date('d F Y'); ?></p>
                        <p>Wali Kelas <?php echo $guru['nama_kelas']; ?></p>
                        <br><br><br>
                        <p style="text-decoration: underline;"><?php echo $guru['nama_guru']; ?></p>
                        <p>NIP. <?php echo $guru['nip']; ?></p>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto submit filter
        document.querySelectorAll('select[name="filter_bulan"], select[name="filter_tahun"], select[name="filter_status"]').forEach(select => {
            select.addEventListener('change', function() {
                this.form.submit();
            });
        });
    </script>
</body>
</html>