<?php
require_once '../config/database.php';
cekRole(['wali_kelas']);

$conn = koneksiDB();
$user_id = $_SESSION['user_id'];

// ================ HANDLE PENCARIAN & FILTER ================
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$filter_bulan = isset($_GET['filter_bulan']) ? $conn->real_escape_string($_GET['filter_bulan']) : '';
$filter_tahun = isset($_GET['filter_tahun']) ? $conn->real_escape_string($_GET['filter_tahun']) : '';

// Get guru/wali kelas data
$guru = $conn->query("
    SELECT g.*, wk.id_kelas, k.nama_kelas 
    FROM guru g 
    LEFT JOIN wali_kelas wk ON g.id_guru = wk.id_guru 
    LEFT JOIN kelas k ON wk.id_kelas = k.id_kelas 
    WHERE g.user_id = $user_id
")->fetch_assoc();

if (!$guru || !$guru['id_kelas']) {
    die("<script>
        alert('❌ Anda belum ditugaskan sebagai wali kelas!');
        window.location.href = 'dashboard.php';
    </script>");
}

$id_kelas = $guru['id_kelas'];

// ================ BULAN & TAHUN LIST ================
$bulan_list = getBulanList();
$tahun_list = getTahunList();

// ================ QUERY PEMBAYARAN DENGAN FILTER ================
$sql = "
    SELECT p.*, s.nama_siswa, s.nisn 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
";

if (!empty($search)) {
    $sql .= " AND (s.nama_siswa LIKE '%$search%' 
               OR s.nisn LIKE '%$search%' 
               OR p.no_kwitansi LIKE '%$search%')";
}

if (!empty($filter_bulan)) {
    $sql .= " AND p.bulan = '$filter_bulan'";
}

if (!empty($filter_tahun)) {
    $sql .= " AND p.tahun = '$filter_tahun'";
}

$sql .= " ORDER BY p.tanggal_bayar DESC, p.id_pembayaran DESC";
$pembayaran = $conn->query($sql);

// ================ STATISTIK ================
$total_transaksi = $conn->query("
    SELECT COUNT(*) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
")->fetch_assoc()['total'];

$total_dana = $conn->query("
    SELECT SUM(p.jumlah) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
")->fetch_assoc()['total'] ?? 0;

$total_siswa = $conn->query("
    SELECT COUNT(*) as total 
    FROM siswa 
    WHERE id_kelas = $id_kelas
")->fetch_assoc()['total'];

$siswa_sudah_bayar = $conn->query("
    SELECT COUNT(DISTINCT p.id_siswa) as total 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    WHERE s.id_kelas = $id_kelas
")->fetch_assoc()['total'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Kelas - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .navbar-brand, .navbar .text-white {
            color: white !important;
        }
        .badge-wali {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 500;
        }
        .navbar .btn-outline-light {
            border-color: rgba(255,255,255,0.5);
        }
        .navbar .btn-outline-light:hover {
            background: white;
            color: #667eea;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 25px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        }
        .card-header {
            background: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            border-radius: 15px 15px 0 0 !important;
            padding: 1.2rem 1.5rem;
            font-weight: 600;
        }
        .stat-card {
            transition: transform 0.3s;
            border-radius: 15px;
            overflow: hidden;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .card-body {
            padding: 25px;
        }
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            color: #495057;
            font-weight: 600;
        }
        .table tbody tr:hover {
            background-color: rgba(102, 126, 234, 0.05);
        }
        .badge-bulan {
            background: #e3f2fd;
            color: #0d47a1;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
        }
        .filter-box {
            background: white;
            border-radius: 12px;
            padding: 20px;
        }
        .class-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 25px 30px;
            margin-bottom: 30px;
        }
        .info-card {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            border-radius: 10px;
            padding: 20px;
        }
        .btn-filter {
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-filter:hover {
            background: #5a67d8;
            color: white;
        }
        .btn-reset {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                <i class="bi bi-cash-coin fs-3 me-2"></i>
                <div>
                    <span class="fw-bold fs-5">SOPP</span>
                    <br>
                    <small>SMKN 1 DLANGGU</small>
                </div>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="badge-wali me-3">
                    <i class="bi bi-person-badge"></i> 
                    <strong><?php echo htmlspecialchars($guru['nama_guru']); ?></strong>
                </span>
                <span class="badge bg-light text-dark me-3">
                    <i class="bi bi-door-open"></i> <?php echo htmlspecialchars($guru['nama_kelas']); ?>
                </span>
                <a href="dashboard.php" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-arrow-left"></i> Dashboard
                </a>
                <a href="../logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- HEADER KELAS -->
        <div class="class-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="fw-bold mb-2">
                        <i class="bi bi-cash-coin me-2"></i>Riwayat Pembayaran
                    </h2>
                    <h4 class="mb-2"><?php echo htmlspecialchars($guru['nama_kelas']); ?></h4>
                    <p class="mb-0 opacity-75">
                        <i class="bi bi-person"></i> Wali Kelas: <strong><?php echo htmlspecialchars($guru['nama_guru']); ?></strong>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <i class="bi bi-clock-history display-1 opacity-25"></i>
                </div>
            </div>
        </div>
        
        <!-- STATISTIK CARD -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Total Transaksi</h6>
                                <h2 class="display-6 mb-0 fw-bold"><?php echo $total_transaksi; ?></h2>
                                <small class="text-white-50">Kali pembayaran</small>
                            </div>
                            <i class="bi bi-cash-stack fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-success text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Total Dana</h6>
                                <h3 class="mb-0 fw-bold"><?php echo formatRupiah($total_dana); ?></h3>
                                <small class="text-white-50">Terkumpul</small>
                            </div>
                            <i class="bi bi-coin fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Total Siswa</h6>
                                <h2 class="display-6 mb-0 fw-bold"><?php echo $total_siswa; ?></h2>
                                <small class="text-white-50">Orang</small>
                            </div>
                            <i class="bi bi-people-fill fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-warning text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Siswa Membayar</h6>
                                <h2 class="display-6 mb-0 fw-bold"><?php echo $siswa_sudah_bayar; ?></h2>
                                <small class="text-white-50">Dari <?php echo $total_siswa; ?> siswa</small>
                            </div>
                            <i class="bi bi-check-circle-fill fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FILTER & PENCARIAN -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">
                    <i class="bi bi-funnel me-2 text-primary"></i>
                    Filter Pembayaran
                </h5>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-5">
                        <label class="form-label fw-bold">
                            <i class="bi bi-search"></i> Pencarian
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-white">
                                <i class="bi bi-search text-muted"></i>
                            </span>
                            <input type="text" class="form-control border-start-0" name="search" 
                                   placeholder="Cari Nama Siswa, NISN, atau No. Kwitansi..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="bi bi-search"></i> Cari
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label fw-bold">
                            <i class="bi bi-calendar"></i> Filter Bulan
                        </label>
                        <select class="form-select" name="filter_bulan">
                            <option value="">-- Semua Bulan --</option>
                            <?php foreach($bulan_list as $bulan): ?>
                            <option value="<?php echo $bulan; ?>" <?php echo $filter_bulan == $bulan ? 'selected' : ''; ?>>
                                <?php echo $bulan; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label fw-bold">
                            <i class="bi bi-calendar3"></i> Filter Tahun
                        </label>
                        <select class="form-select" name="filter_tahun">
                            <option value="">-- Semua --</option>
                            <?php foreach($tahun_list as $tahun): ?>
                            <option value="<?php echo $tahun; ?>" <?php echo $filter_tahun == $tahun ? 'selected' : ''; ?>>
                                <?php echo $tahun; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label fw-bold">Aksi</label>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-filter"></i> Terapkan
                            </button>
                        </div>
                    </div>
                    
                    <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun)): ?>
                    <div class="col-12 mt-3">
                        <a href="pembayaran.php" class="btn btn-sm btn-secondary">
                            <i class="bi bi-x-circle"></i> Reset Filter
                        </a>
                        <span class="badge bg-info ms-2 py-2 px-3">Filter Aktif</span>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <!-- TABEL PEMBAYARAN -->
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2 text-primary"></i>
                    Riwayat Pembayaran
                    <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun)): ?>
                        <span class="badge bg-info ms-2">Hasil Filter</span>
                    <?php endif; ?>
                </h5>
                <span class="badge bg-primary py-2 px-3">
                    <i class="bi bi-cash"></i> <?php echo $pembayaran->num_rows; ?> Transaksi
                </span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th width="20%">Nama Siswa</th>
                                <th width="12%">NISN</th>
                                <th width="15%">Bulan/Tahun</th>
                                <th width="15%">Jumlah</th>
                                <th width="13%">Tanggal Bayar</th>
                                <th width="20%">No. Kwitansi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($pembayaran && $pembayaran->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $pembayaran->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold text-center"><?php echo $no++; ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($row['nama_siswa']); ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary py-2 px-3">
                                            <?php echo htmlspecialchars($row['nisn']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info py-2 px-3">
                                            <i class="bi bi-calendar me-1"></i>
                                            <?php echo $row['bulan'] . ' ' . $row['tahun']; ?>
                                        </span>
                                    </td>
                                    <td class="fw-bold text-success fs-5">
                                        <?php echo formatRupiah($row['jumlah']); ?>
                                    </td>
                                    <td>
                                        <i class="bi bi-calendar-check text-primary me-1"></i>
                                        <?php echo date('d/m/Y', strtotime($row['tanggal_bayar'])); ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border py-2 px-3" style="font-family: monospace;">
                                            <i class="bi bi-receipt me-1"></i>
                                            <?php echo htmlspecialchars($row['no_kwitansi']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <div class="py-4">
                                            <i class="bi bi-cash-coin display-1 text-muted"></i>
                                            <h5 class="mt-4 text-muted">
                                                <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun)): ?>
                                                    Tidak ditemukan data pembayaran dengan filter yang dipilih
                                                <?php else: ?>
                                                    Belum ada data pembayaran di kelas ini
                                                <?php endif; ?>
                                            </h5>
                                            <p class="text-muted mb-0">
                                                <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun)): ?>
                                                    <a href="pembayaran.php" class="btn btn-outline-primary mt-3">
                                                        <i class="bi bi-arrow-left"></i> Tampilkan semua data
                                                    </a>
                                                <?php else: ?>
                                                    Siswa belum melakukan pembayaran SOPP
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- INFORMASI TAMBAHAN -->
        <div class="row mt-4">
            <div class="col-md-6 mb-3">
                <div class="card bg-light border-0 h-100">
                    <div class="card-body">
                        <h6 class="fw-bold text-primary mb-3">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            Informasi
                        </h6>
                        <ul class="list-unstyled mb-0">
                            <li class="mb-3 d-flex">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Hanya admin yang dapat mencetak kwitansi pembayaran</span>
                            </li>
                            <li class="mb-3 d-flex">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Wali kelas hanya dapat melihat riwayat pembayaran</span>
                            </li>
                            <li class="mb-3 d-flex">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Laporan lengkap tersedia di menu Laporan</span>
                            </li>
                            <li class="d-flex">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Biaya SOPP: <strong><?php echo formatRupiah(SOPP_BIAYA); ?></strong> per bulan</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card bg-light border-0 h-100">
                    <div class="card-body">
                        <h6 class="fw-bold text-primary mb-3">
                            <i class="bi bi-pie-chart-fill me-2"></i>
                            Ringkasan
                        </h6>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <div class="bg-white p-3 rounded-3">
                                    <small class="text-muted d-block">Total Siswa</small>
                                    <h3 class="fw-bold text-primary mb-0"><?php echo $total_siswa; ?></h3>
                                    <small>orang</small>
                                </div>
                            </div>
                            <div class="col-6 mb-3">
                                <div class="bg-white p-3 rounded-3">
                                    <small class="text-muted d-block">Siswa Membayar</small>
                                    <h3 class="fw-bold text-success mb-0"><?php echo $siswa_sudah_bayar; ?></h3>
                                    <small>orang</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="bg-white p-3 rounded-3">
                                    <small class="text-muted d-block">Total Transaksi</small>
                                    <h3 class="fw-bold text-info mb-0"><?php echo $total_transaksi; ?></h3>
                                    <small>kali</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="bg-white p-3 rounded-3">
                                    <small class="text-muted d-block">Total Dana</small>
                                    <h3 class="fw-bold text-warning mb-0"><?php echo formatRupiah($total_dana); ?></h3>
                                    <small>terkumpul</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- LINK KE LAPORAN (TAMBAHAN) -->
        <div class="text-center mb-4">
            <a href="laporan.php" class="btn btn-outline-primary btn-lg">
                <i class="bi bi-file-text me-2"></i>
                Lihat Laporan Lengkap Kelas
            </a>
            <p class="text-muted mt-2 small">
                <i class="bi bi-info-circle"></i> 
                Untuk mencetak laporan pembayaran, silakan kunjungi halaman Laporan
            </p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Auto submit filter -->
    <script>
        document.querySelectorAll('select[name="filter_bulan"], select[name="filter_tahun"]').forEach(select => {
            select.addEventListener('change', function() {
                this.form.submit();
            });
        });
    </script>
</body>
</html>