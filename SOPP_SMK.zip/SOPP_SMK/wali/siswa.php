<?php
require_once '../config/database.php';
cekRole(['wali_kelas']);

$conn = koneksiDB();
$user_id = $_SESSION['user_id'];

// Get guru/wali kelas data
$guru = $conn->query("
    SELECT g.*, wk.id_kelas, k.nama_kelas 
    FROM guru g 
    LEFT JOIN wali_kelas wk ON g.id_guru = wk.id_guru 
    LEFT JOIN kelas k ON wk.id_kelas = k.id_kelas 
    WHERE g.user_id = $user_id
")->fetch_assoc();

if (!$guru || !$guru['id_kelas']) {
    die("<script>
        alert('❌ Anda belum ditugaskan sebagai wali kelas!');
        window.location.href = 'dashboard.php';
    </script>");
}

$id_kelas = $guru['id_kelas'];

// ================ HANDLE PENCARIAN ================
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// ================ GET STUDENTS WITH SEARCH ================
if (!empty($search)) {
    $siswa = $conn->query("
        SELECT * FROM siswa 
        WHERE id_kelas = $id_kelas 
        AND (nisn LIKE '%$search%' 
            OR nama_siswa LIKE '%$search%' 
            OR no_telp LIKE '%$search%')
        ORDER BY nama_siswa
    ");
} else {
    $siswa = $conn->query("
        SELECT * FROM siswa 
        WHERE id_kelas = $id_kelas 
        ORDER BY nama_siswa
    ");
}

// ================ GET STATISTICS ================
$total_siswa = $siswa->num_rows;

$siswa_laki = $conn->query("
    SELECT COUNT(*) as total FROM siswa 
    WHERE id_kelas = $id_kelas AND jenis_kelamin = 'L'
")->fetch_assoc()['total'];

$siswa_perempuan = $conn->query("
    SELECT COUNT(*) as total FROM siswa 
    WHERE id_kelas = $id_kelas AND jenis_kelamin = 'P'
")->fetch_assoc()['total'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        }
        .navbar-brand, .navbar .text-white {
            color: white !important;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.2rem 1.5rem;
        }
        .table thead th {
            border-bottom: 2px solid #dee2e6;
            color: #495057;
            font-weight: 600;
        }
        .stat-card {
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .search-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .badge-wali {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <i class="bi bi-cash-coin fs-3 me-2"></i>
                <div>
                    <span class="fw-bold fs-5">SOPP</span>
                    <br>
                    <small>SMKN 1 DLANGGU</small>
                </div>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="badge-wali me-3">
                    <i class="bi bi-person-badge"></i> 
                    <strong><?php echo $guru['nama_guru']; ?></strong>
                </span>
                <span class="badge bg-light text-dark me-3">
                    <i class="bi bi-door-open"></i> Kelas <?php echo $guru['nama_kelas']; ?>
                </span>
                <a href="dashboard.php" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-arrow-left"></i> Dashboard
                </a>
                <a href="../logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-primary mb-1">
                    <i class="bi bi-people-fill"></i> Data Siswa
                </h3>
                <p class="text-muted mb-0">
                    <i class="bi bi-door-open"></i> Kelas <?php echo htmlspecialchars($guru['nama_kelas']); ?> | 
                    Wali Kelas: <?php echo htmlspecialchars($guru['nama_guru']); ?>
                </p>
            </div>
        </div>
        
        <!-- SEARCH FORM -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label fw-bold">
                            <i class="bi bi-search"></i> Pencarian
                        </label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" 
                                   placeholder="Cari berdasarkan NISN, Nama Siswa, atau No. Telepon..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="bi bi-search"></i> Cari
                            </button>
                            <?php if (!empty($search)): ?>
                            <a href="siswa.php" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Reset
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-info-circle"></i> Informasi
                        </label>
                        <div class="form-control bg-light">
                            <i class="bi bi-people"></i> Total Siswa: <strong><?php echo $total_siswa; ?></strong>
                            <?php if (!empty($search)): ?>
                                <span class="badge bg-info ms-2">Hasil Pencarian</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- TABLE SISWA -->
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2"></i> Daftar Siswa Kelas <?php echo $guru['nama_kelas']; ?>
                    <?php if (!empty($search)): ?>
                        <span class="badge bg-info ms-2">Keyword: "<?php echo htmlspecialchars($search); ?>"</span>
                    <?php endif; ?>
                </h5>
                <span class="badge bg-primary"><?php echo $total_siswa; ?> Siswa</span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th width="15%">NISN</th>
                                <th width="25%">Nama Siswa</th>
                                <th width="12%">Jenis Kelamin</th>
                                <th width="15%">Telepon</th>
                                <th width="13%">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($siswa && $siswa->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $siswa->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($row['nisn']); ?></span>
                                    </td>
                                    <td class="fw-bold">
                                        <?php echo htmlspecialchars($row['nama_siswa']); ?>
                                    </td>
                                    <td>
                                        <?php if($row['jenis_kelamin'] == 'L'): ?>
                                            <span class="badge bg-primary">
                                                <i class="bi bi-gender-male"></i> Laki-laki
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-gender-female"></i> Perempuan
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(!empty($row['no_telp'])): ?>
                                            <i class="bi bi-telephone"></i> <?php echo htmlspecialchars($row['no_telp']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">
                                            <i class="bi bi-check-circle"></i> Aktif
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="bi bi-people display-1 text-muted"></i>
                                        <h5 class="mt-3 text-muted">
                                            <?php if (!empty($search)): ?>
                                                Tidak ditemukan data siswa dengan kata kunci "<?php echo htmlspecialchars($search); ?>"
                                            <?php else: ?>
                                                Belum ada data siswa di kelas ini
                                            <?php endif; ?>
                                        </h5>
                                        <?php if (!empty($search)): ?>
                                        <a href="siswa.php" class="btn btn-outline-primary mt-3">
                                            <i class="bi bi-arrow-left"></i> Tampilkan semua siswa
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- STATISTIK -->
        <div class="row mt-4">
            <div class="col-md-4 mb-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Total Siswa</h6>
                                <h2 class="display-6 mb-0"><?php echo $total_siswa; ?></h2>
                                <small>Siswa aktif</small>
                            </div>
                            <i class="bi bi-people-fill fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Laki-laki</h6>
                                <h2 class="display-6 mb-0"><?php echo $siswa_laki; ?></h2>
                                <small>Siswa</small>
                            </div>
                            <i class="bi bi-gender-male fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card stat-card bg-danger text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-2">Perempuan</h6>
                                <h2 class="display-6 mb-0"><?php echo $siswa_perempuan; ?></h2>
                                <small>Siswa</small>
                            </div>
                            <i class="bi bi-gender-female fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- INFO BOTTOM -->
        <div class="row mt-2">
            <div class="col-12">
                <div class="card bg-light">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-info-circle-fill fs-4 text-primary me-3"></i>
                            <div>
                                <strong>Informasi:</strong> Halaman ini hanya menampilkan siswa dari kelas yang Anda ampu sebagai wali kelas.
                                <?php if (!empty($search)): ?>
                                    <br><small class="text-muted">Menampilkan hasil pencarian untuk keyword "<?php echo htmlspecialchars($search); ?>"</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>