<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<div class="col-md-2 bg-dark text-white min-vh-100 p-0">
    <div class="p-3">
        <h5 class="text-center"><?php echo APP_NAME; ?></h5>
        <p class="text-center small">SMKN 1 DLANGGU</p>
        <hr>
        <div class="text-center mb-3">
            <span class="badge bg-primary">ADMIN</span>
            <div class="small mt-1"><?php echo $_SESSION['username']; ?></div>
        </div>
    </div>
    
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'bg-primary' : ''; ?>" 
               href="dashboard.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'bg-primary' : ''; ?>" 
               href="siswa.php">
                <i class="bi bi-people me-2"></i> Data Siswa
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'guru.php' ? 'bg-primary' : ''; ?>" 
               href="guru.php">
                <i class="bi bi-person-badge me-2"></i> Data Guru
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'kelas.php' ? 'bg-primary' : ''; ?>" 
               href="kelas.php">
                <i class="bi bi-building me-2"></i> Kelas
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'wali_kelas.php' ? 'bg-primary' : ''; ?>" 
               href="wali_kelas.php">
                <i class="bi bi-person-check me-2"></i> Wali Kelas
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'pembayaran.php' ? 'bg-primary' : ''; ?>" 
               href="pembayaran.php">
                <i class="bi bi-cash-coin me-2"></i> Pembayaran
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'bg-primary' : ''; ?>" 
               href="laporan.php">
                <i class="bi bi-file-text me-2"></i> Laporan
            </a>
        </li>
        <li class="nav-item mt-4">
            <a class="nav-link text-white bg-danger" href="../logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> Logout
            </a>
        </li>
    </ul>
</div>

<style>
    
    .nav-link {
        padding: 12px 20px;
        border-left: 3px solid transparent;
    }
    .nav-link:hover, .nav-link.bg-primary {
        border-left-color: white;
    }
    
</style>