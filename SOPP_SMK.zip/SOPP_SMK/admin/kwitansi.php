<?php
require_once '../config/database.php';

// Mulai session jika belum
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Definisikan fungsi cekRole jika belum ada
if (!function_exists('cekRole')) {
    function cekRole($allowed_roles) {
        if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
            header('Location: ../login.php');
            exit;
        }
    }
}

cekRole(['admin','wali_kelas','siswa']);

$conn = koneksiDB();

// DEBUG: Tampilkan semua parameter yang diterima
$id = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['id']) ? $_POST['id'] : 0);

// Untuk debugging, hapus setelah selesai
if (isset($_GET['debug'])) {
    echo "<div style='background:#f0f0f0; padding:10px; margin:10px; border:1px solid #ccc;'>";
    echo "<h3>Debug Info:</h3>";
    echo "ID dari URL: " . ($_GET['id'] ?? 'tidak ada') . "<br>";
    echo "Tipe ID: " . gettype($_GET['id'] ?? 'null') . "<br>";
    echo "Semua GET params: <pre>" . print_r($_GET, true) . "</pre>";
    echo "URL: " . (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]<br>";
    echo "</div>";
}

// Bersihkan ID
$id = trim($id);
$id = filter_var($id, FILTER_SANITIZE_NUMBER_INT);
$id = (int)$id;

// Validasi ID
if ($id <= 0) {
    // Coba cek dari referer untuk debugging
    $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'tidak ada';
    
    die("
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 5px;'>
        <h2 style='color: #856404; margin-top: 0;'>❌ ID Pembayaran Tidak Valid</h2>
        <p style='margin-bottom: 20px;'>ID yang diterima: <strong>" . htmlspecialchars($id) . "</strong></p>
        <p>Halaman sebelumnya: " . htmlspecialchars($referer) . "</p>
        <p>Debug info:</p>
        <ul>
            <li>GET id: " . htmlspecialchars($_GET['id'] ?? 'tidak ada') . "</li>
            <li>POST id: " . htmlspecialchars($_POST['id'] ?? 'tidak ada') . "</li>
            <li>REQUEST_URI: " . htmlspecialchars($_SERVER['REQUEST_URI'] ?? 'tidak ada') . "</li>
        </ul>
        <div style='margin-top: 30px;'>
            <a href='pembayaran.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>⬅ Kembali ke Halaman Pembayaran</a>
        </div>
    </div>
    ");
}

// Query untuk cek struktur tabel pembayaran
$check_columns = $conn->query("SHOW COLUMNS FROM pembayaran");
$columns = [];
while ($col = $check_columns->fetch_assoc()) {
    $columns[] = $col['Field'];
}

// Buat SELECT query dinamis
$select_fields = "p.*, 
                  s.nama_siswa, s.nisn,
                  k.nama_kelas, k.tingkat, k.jurusan,
                  g.nama_guru as petugas";

// Tambahkan field jika ada di tabel
if (in_array('bulan', $columns)) $select_fields .= ", p.bulan";
if (in_array('tahun', $columns)) $select_fields .= ", p.tahun";
if (in_array('no_kwitansi', $columns)) $select_fields .= ", p.no_kwitansi";

$query = "
SELECT $select_fields
FROM pembayaran p
JOIN siswa s ON p.id_siswa = s.id_siswa
JOIN kelas k ON s.id_kelas = k.id_kelas
LEFT JOIN guru g ON p.id_petugas = g.id_guru
WHERE p.id_pembayaran = ?
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Error prepare statement: " . $conn->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Cek apakah data ditemukan
if ($result->num_rows === 0) {
    die("
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px;'>
        <h2 style='color: #721c24; margin-top: 0;'>❌ Data Tidak Ditemukan</h2>
        <p>Tidak ada pembayaran dengan ID: <strong>$id</strong></p>
        <p>Kemungkinan data sudah dihapus atau ID salah.</p>
        <div style='margin-top: 30px;'>
            <a href='pembayaran.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>⬅ Kembali ke Halaman Pembayaran</a>
        </div>
    </div>
    ");
}

$data = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Default value untuk field yang mungkin tidak ada
$no_kwitansi = isset($data['no_kwitansi']) && !empty($data['no_kwitansi']) 
    ? $data['no_kwitansi'] 
    : 'KW-' . date('Ymd') . '-' . str_pad($id, 4, '0', STR_PAD_LEFT);

$bulan = isset($data['bulan']) && !empty($data['bulan']) 
    ? $data['bulan'] 
    : date('F', strtotime($data['tanggal_bayar']));

$tahun = isset($data['tahun']) && !empty($data['tahun']) 
    ? $data['tahun'] 
    : date('Y', strtotime($data['tanggal_bayar']));

$tanggal = date('d-m-Y', strtotime($data['tanggal_bayar']));

// Fungsi terbilang
if (!function_exists('formatTerbilangRupiah')) {
    function formatTerbilangRupiah($angka) {
        $angka = (float)$angka;
        if ($angka < 0) return "Minus " . trim(formatTerbilangRupiah(abs($angka)));
        
        $bilangan = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
        
        if ($angka < 12) {
            return $bilangan[$angka] . " Rupiah";
        } else if ($angka < 20) {
            return formatTerbilangRupiah($angka - 10) . " Belas Rupiah";
        } else if ($angka < 100) {
            $hasil = formatTerbilangRupiah(floor($angka / 10)) . " Puluh";
            $sisa = $angka % 10;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else if ($angka < 200) {
            return "Seratus " . formatTerbilangRupiah($angka - 100);
        } else if ($angka < 1000) {
            $hasil = formatTerbilangRupiah(floor($angka / 100)) . " Ratus";
            $sisa = $angka % 100;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else if ($angka < 2000) {
            return "Seribu " . formatTerbilangRupiah($angka - 1000);
        } else if ($angka < 1000000) {
            $hasil = formatTerbilangRupiah(floor($angka / 1000)) . " Ribu";
            $sisa = $angka % 1000;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else if ($angka < 1000000000) {
            $hasil = formatTerbilangRupiah(floor($angka / 1000000)) . " Juta";
            $sisa = $angka % 1000000;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else if ($angka < 1000000000000) {
            $hasil = formatTerbilangRupiah(floor($angka / 1000000000)) . " Milyar";
            $sisa = $angka % 1000000000;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else if ($angka < 1000000000000000) {
            $hasil = formatTerbilangRupiah(floor($angka / 1000000000000)) . " Trilyun";
            $sisa = $angka % 1000000000000;
            if ($sisa > 0) {
                $hasil .= " " . formatTerbilangRupiah($sisa);
            }
            return $hasil;
        } else {
            return "Angka terlalu besar";
        }
    }
}

$terbilang = formatTerbilangRupiah($data['jumlah']);

// ===== RINCIAN =====
$dana_kegiatan = 50000;
$sopp_perbulan = 150000;
$jumlah_bulan = $data['jumlah'] > $dana_kegiatan ? ($data['jumlah'] - $dana_kegiatan) / $sopp_perbulan : 0;
$sopp_total = $sopp_perbulan * $jumlah_bulan;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Kwitansi Pembayaran - <?= htmlspecialchars($data['nama_siswa']) ?></title>
<style>
/* [style sama seperti sebelumnya] */
@media print{
    @page { 
        size: A4 landscape; 
        margin: 10mm; 
    }
    .no-print{ 
        display: none !important; 
    }
}

body{
    font-family: "Courier New", monospace;
    background: #eee;
    padding: 20px;
    margin: 0;
}

.controls{
    text-align: center;
    margin-bottom: 15px;
    position: relative;
    z-index: 9999;
}
.controls button{
    padding: 10px 20px;
    font-size: 14px;
    cursor: pointer;
    margin: 0 5px;
    background: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
}
.controls button:hover{
    background: #45a049;
}
.controls button:last-child{
    background: #f44336;
}
.controls button:last-child:hover{
    background: #da190b;
}

.kwitansi{
    width: 297mm;
    background: #fff;
    padding: 12mm 18mm;
    border: 1px dashed #000;
    margin: auto;
    position: relative;
    box-sizing: border-box;
}

.header{
    text-align: center;
    font-weight: bold;
    letter-spacing: 2px;
    font-size: 18px;
}
.sub{
    text-align: center;
    margin-bottom: 6px;
}
.line{
    border-top: 1px dashed #000;
    margin: 6px 0;
}

.label{
    display: inline-block;
    width: 120px;
}

.rincian table{
    width: 100%;
    margin-top: 6px;
}
.rincian td{
    padding: 2px 0;
}

.total{
    border-top: 1px solid #000;
    margin-top: 6px;
    padding-top: 4px;
    font-weight: bold;
    font-size: 16px;
}

.sign-area{
    margin-top: 35px;
    display: flex;
    justify-content: space-between;
}

.sign-box{
    width: 40%;
    text-align: center;
}
.sign-line{
    margin-top: 55px;
    border-top: 1px solid #000;
    padding-top: 5px;
}
</style>
</head>

<body>

<div class="controls no-print">
    <button onclick="window.print()">🖨 Cetak Kwitansi</button>
    <button onclick="goBack()">⬅ Kembali</button>
</div>

<div class="kwitansi">

    <div class="header">SMK NEGERI 1 DLANGGU MOJOKERTO</div>
    <div class="sub">Jl. A. Yani No 01 Ds. Pohkecik</div>
    <div class="line"></div>

    <div><span class="label">NO. KWITANSI</span>: <?= htmlspecialchars($no_kwitansi) ?></div>
    <div><span class="label">NISN</span>: <?= htmlspecialchars($data['nisn']) ?></div>
    <div><span class="label">NAMA</span>: <?= htmlspecialchars(strtoupper($data['nama_siswa'])) ?></div>
    <div><span class="label">KELAS</span>: <?= htmlspecialchars($data['tingkat'] . ' ' . $data['jurusan']) ?></div>

    <div class="line"></div>
    <b>Rincian Pembayaran :</b>

    <div class="rincian">
        <table>
            <tr>
                <td width="5%">01.</td>
                <td>Dana Kegiatan Personal Siswa</td>
                <td align="right">Rp <?= number_format($dana_kegiatan, 0, ',', '.') ?></td>
            </tr>
            <tr>
                <td>02.</td>
                <td>Sumbangan Operasional & Pengembangan Pendidikan  
                    Kelas <?= htmlspecialchars($data['tingkat']) ?> Bulan <?= htmlspecialchars($bulan) ?>/<?= htmlspecialchars($tahun) ?>
                </td>
                <td align="right">Rp <?= number_format($sopp_total, 0, ',', '.') ?></td>
            </tr>
        </table>
    </div>

    <div class="total">
        TOTAL : Rp <?= number_format($data['jumlah'], 0, ',', '.') ?>
    </div>

    <div>Terbilang : # <?= htmlspecialchars($terbilang) ?> #</div>

    <div class="sign-area">
        <div class="sign-box">
            Petugas<br>
            Mojokerto, <?= htmlspecialchars($tanggal) ?>
            <div class="sign-line"></div>
            <?= htmlspecialchars($data['petugas'] ?? 'Petugas Administrasi') ?>
        </div>

        <div class="sign-box">
            Siswa
            <div class="sign-line"></div>
            <?= htmlspecialchars(strtoupper($data['nama_siswa'])) ?>
        </div>
    </div>

</div>

<script>
function goBack(){
    // Coba beberapa metode untuk kembali
    if (window.history.length > 1) {
        window.history.back();
    } else if (document.referrer) {
        window.location.href = document.referrer;
    } else if (window.opener) {
        window.close();
    } else {
        window.location.href = "pembayaran.php";
    }
}

// Untuk debugging - tampilkan parameter di console
console.log("Kwitansi ID:", <?= json_encode($id) ?>);
console.log("Data pembayaran:", <?= json_encode($data) ?>);
</script>

</body>
</html>