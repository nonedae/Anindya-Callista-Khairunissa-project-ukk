<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

// Hitung statistik
$total_siswa = $conn->query("SELECT COUNT(*) as total FROM siswa")->fetch_assoc()['total'];
$total_guru = $conn->query("SELECT COUNT(*) as total FROM guru")->fetch_assoc()['total'];
$total_kelas = $conn->query("SELECT COUNT(*) as total FROM kelas")->fetch_assoc()['total'];

// Pembayaran bulan ini
$bulan_ini = date('m');
$tahun_ini = date('Y');
$total_pembayaran = $conn->query("SELECT SUM(jumlah) as total FROM pembayaran 
                                 WHERE MONTH(tanggal_bayar) = '$bulan_ini' 
                                 AND YEAR(tanggal_bayar) = '$tahun_ini'")->fetch_assoc()['total'] ?? 0;

// Pembayaran terbaru
$pembayaran_terbaru = $conn->query("SELECT p.*, s.nama_siswa, k.nama_kelas 
                                   FROM pembayaran p 
                                   JOIN siswa s ON p.id_siswa = s.id_siswa 
                                   JOIN kelas k ON s.id_kelas = k.id_kelas 
                                   ORDER BY p.tanggal_bayar DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- MAIN CONTENT -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3><i class="bi bi-speedometer2"></i> Dashboard Admin</h3>
                <div class="text-end">
                    <span class="badge bg-primary"><?php echo $_SESSION['username']; ?></span>
                    <small class="text-muted">(<?php echo $_SESSION['role']; ?>)</small>
                </div>
            </div>

            <!-- Statistik -->
            <div class="row g-4 mb-4">
                <div class="col-md-3">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6>Total Siswa</h6>
                                <h2 class="fw-bold"><?php echo $total_siswa; ?></h2>
                            </div>
                            <i class="bi bi-people display-6 opacity-50"></i>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-white bg-success h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6>Total Guru</h6>
                                <h2 class="fw-bold"><?php echo $total_guru; ?></h2>
                            </div>
                            <i class="bi bi-person-badge display-6 opacity-50"></i>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-white bg-info h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6>Total Kelas</h6>
                                <h2 class="fw-bold"><?php echo $total_kelas; ?></h2>
                            </div>
                            <i class="bi bi-building display-6 opacity-50"></i>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6>Pembayaran Bulan Ini</h6>
                                <h5 class="fw-bold">Rp <?php echo number_format($total_pembayaran, 0, ',', '.'); ?></h5>
                            </div>
                            <i class="bi bi-cash-coin display-6 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pembayaran Terbaru - TANPA AKSI CETAK -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-clock-history"></i> Pembayaran Terbaru</h5>
                    <a href="pembayaran.php" class="btn btn-sm btn-primary">
                        <i class="bi bi-arrow-right"></i> Lihat Semua
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th>Siswa</th>
                                    <th>Kelas</th>
                                    <th>Bulan/Tahun</th>
                                    <th>Jumlah</th>
                                    <th>Tanggal</th>
                                    <!-- KOLOM AKSI DIHAPUS -->
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($pembayaran_terbaru)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-3">
                                        <i class="bi bi-inbox"></i> Belum ada data pembayaran
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1; foreach ($pembayaran_terbaru as $p): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($p['nama_siswa']) ?></td>
                                    <td><?= htmlspecialchars($p['nama_kelas']) ?></td>
                                    <td><?= htmlspecialchars($p['bulan'] . ' ' . $p['tahun']) ?></td>
                                    <td><?= formatRupiah($p['jumlah']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($p['tanggal_bayar'])) ?></td>
                                    <!-- TOMBOL CETAK DIHAPUS -->
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>