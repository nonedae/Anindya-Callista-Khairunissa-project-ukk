<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

// ============ HANDLE TAMBAH SISWA ============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_siswa'])) {
    $nisn = trim($_POST['nisn']);
    $nama_siswa = trim($_POST['nama_siswa']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $id_kelas = $_POST['id_kelas'];
    $no_telp = isset($_POST['no_telp']) ? trim($_POST['no_telp']) : '';
    $tanggal_lahir = isset($_POST['tanggal_lahir']) && !empty($_POST['tanggal_lahir']) ? trim($_POST['tanggal_lahir']) : null;
    $alamat = isset($_POST['alamat']) ? trim($_POST['alamat']) : '';
    
    // Validasi input
    $errors = [];
    
    if (empty($nisn)) $errors[] = "NISN harus diisi";
    elseif (!ctype_digit($nisn)) $errors[] = "NISN hanya boleh berisi angka";
    elseif (strlen($nisn) < 10) $errors[] = "NISN minimal 10 digit";
    
    if (empty($nama_siswa)) $errors[] = "Nama siswa harus diisi";
    if (empty($jenis_kelamin)) $errors[] = "Jenis kelamin harus dipilih";
    if (empty($id_kelas)) $errors[] = "Kelas harus dipilih";
    
    if (!empty($no_telp) && !preg_match('/^[0-9+\-\s]+$/', $no_telp)) {
        $errors[] = "Format nomor telepon tidak valid";
    }
    
    if (empty($errors)) {
        // Escape string untuk keamanan
        $nisn = $conn->real_escape_string($nisn);
        $nama_siswa = $conn->real_escape_string($nama_siswa);
        $jenis_kelamin = $conn->real_escape_string($jenis_kelamin);
        $id_kelas = $conn->real_escape_string($id_kelas);
        $no_telp = $conn->real_escape_string($no_telp);
        $alamat = $conn->real_escape_string($alamat);
        $tanggal_lahir = $tanggal_lahir ? "'" . $conn->real_escape_string($tanggal_lahir) . "'" : "NULL";
        
        // Validasi NISN unik
        $check = $conn->query("SELECT id_siswa FROM siswa WHERE nisn = '$nisn'");
        if ($check && $check->num_rows > 0) {
            $error = "❌ NISN sudah terdaftar!";
        } else {
            // Mulai transaksi
            $conn->begin_transaction();
            
            try {
                // 1. Insert ke tabel siswa
                $sql_siswa = "INSERT INTO siswa (nisn, nama_siswa, jenis_kelamin, tanggal_lahir, alamat, no_telp, id_kelas) 
                             VALUES ('$nisn', '$nama_siswa', '$jenis_kelamin', $tanggal_lahir, '$alamat', '$no_telp', '$id_kelas')";
                
                if (!$conn->query($sql_siswa)) {
                    throw new Exception("Gagal menambahkan data siswa: " . $conn->error);
                }
                
                $id_siswa = $conn->insert_id;
                
                // 2. Insert ke tabel users untuk login - HAPUS kolom nama_siswa
                $username = $nisn;
                $password_default = $nisn;
                $hashed_password = password_hash($password_default, PASSWORD_DEFAULT);
                $role = 'siswa';
                
                // Cek apakah username sudah ada di users
                $check_user = $conn->query("SELECT id_user FROM users WHERE username = '$username'");
                if ($check_user && $check_user->num_rows > 0) {
                    throw new Exception("Username (NISN) sudah terdaftar di sistem login!");
                }
                
                // HANYA insert kolom yang ada di tabel users
                $sql_user = "INSERT INTO users (username, password, role, id_siswa, created_at) 
                            VALUES ('$username', '$hashed_password', '$role', '$id_siswa', NOW())";
                
                if (!$conn->query($sql_user)) {
                    throw new Exception("Gagal membuat akun login: " . $conn->error);
                }
                
                $conn->commit();
                
                $_SESSION['flash_message'] = [
                    'type' => 'success',
                    'message' => "✅ Data siswa berhasil ditambahkan!<br>
                                <strong>Nama:</strong> $nama_siswa<br>
                                <strong>Username:</strong> $username<br>
                                <strong>Password:</strong> $password_default"
                ];
                
                header("Location: siswa.php");
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                $error = "❌ " . $e->getMessage();
            }
        }
    } else {
        $error = implode("<br>", array_map(function($e) { return "❌ " . $e; }, $errors));
    }
}

// ============ HANDLE EDIT SISWA ============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_siswa'])) {
    $id_siswa = (int)$_POST['id_siswa'];
    $nisn = trim($_POST['nisn']);
    $nama_siswa = trim($_POST['nama_siswa']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $id_kelas = (int)$_POST['id_kelas'];
    $no_telp = isset($_POST['no_telp']) ? trim($_POST['no_telp']) : '';
    $tanggal_lahir = isset($_POST['tanggal_lahir']) && !empty($_POST['tanggal_lahir']) ? trim($_POST['tanggal_lahir']) : null;
    $alamat = isset($_POST['alamat']) ? trim($_POST['alamat']) : '';
    
    // Validasi input
    $errors = [];
    
    if (!$id_siswa) $errors[] = "ID siswa tidak valid";
    if (empty($nisn)) $errors[] = "NISN harus diisi";
    elseif (!ctype_digit($nisn)) $errors[] = "NISN hanya boleh berisi angka";
    if (empty($nama_siswa)) $errors[] = "Nama siswa harus diisi";
    if (empty($jenis_kelamin)) $errors[] = "Jenis kelamin harus dipilih";
    if (!$id_kelas) $errors[] = "Kelas harus dipilih";
    
    if (empty($errors)) {
        // Escape string
        $nisn = $conn->real_escape_string($nisn);
        $nama_siswa = $conn->real_escape_string($nama_siswa);
        $jenis_kelamin = $conn->real_escape_string($jenis_kelamin);
        $no_telp = $conn->real_escape_string($no_telp);
        $alamat = $conn->real_escape_string($alamat);
        $tanggal_lahir = $tanggal_lahir ? "'" . $conn->real_escape_string($tanggal_lahir) . "'" : "NULL";
        
        // Validasi NISN unik kecuali untuk siswa ini sendiri
        $check = $conn->query("SELECT id_siswa FROM siswa WHERE nisn = '$nisn' AND id_siswa != '$id_siswa'");
        if ($check && $check->num_rows > 0) {
            $error = "❌ NISN sudah terdaftar!";
        } else {
            $conn->begin_transaction();
            
            try {
                // 1. Update data siswa
                $sql_siswa = "UPDATE siswa SET 
                             nisn = '$nisn',
                             nama_siswa = '$nama_siswa',
                             jenis_kelamin = '$jenis_kelamin',
                             tanggal_lahir = $tanggal_lahir,
                             alamat = '$alamat',
                             no_telp = '$no_telp',
                             id_kelas = '$id_kelas'
                             WHERE id_siswa = '$id_siswa'";
                
                if (!$conn->query($sql_siswa)) {
                    throw new Exception("Gagal memperbarui data siswa: " . $conn->error);
                }
                
                // 2. Update data di tabel users - HANYA update username
                $check_user = $conn->query("SELECT id_user FROM users WHERE id_siswa = '$id_siswa'");
                
                if ($check_user && $check_user->num_rows > 0) {
                    // Update username saja, HAPUS update nama_siswa
                    $sql_user = "UPDATE users SET 
                                username = '$nisn'
                                WHERE id_siswa = '$id_siswa'";
                    
                    if (!$conn->query($sql_user)) {
                        throw new Exception("Gagal memperbarui akun login: " . $conn->error);
                    }
                } else {
                    // Buat akun baru jika belum ada
                    $hashed_password = password_hash($nisn, PASSWORD_DEFAULT);
                    $role = 'siswa';
                    
                    $sql_user = "INSERT INTO users (username, password, role, id_siswa, created_at) 
                               VALUES ('$nisn', '$hashed_password', '$role', '$id_siswa', NOW())";
                    
                    if (!$conn->query($sql_user)) {
                        throw new Exception("Gagal membuat akun login: " . $conn->error);
                    }
                }
                
                $conn->commit();
                
                $_SESSION['flash_message'] = [
                    'type' => 'success',
                    'message' => "✅ Data siswa berhasil diperbarui!"
                ];
                
                header("Location: siswa.php");
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                $error = "❌ " . $e->getMessage();
            }
        }
    } else {
        $error = implode("<br>", array_map(function($e) { return "❌ " . $e; }, $errors));
    }
}

// ============ HANDLE HAPUS SISWA ============
if (isset($_GET['hapus'])) {
    $id_siswa = (int)$_GET['hapus'];
    
    if ($id_siswa) {
        // Cek apakah siswa memiliki data pembayaran
        $check_pembayaran = $conn->query("SELECT id_pembayaran FROM pembayaran WHERE id_siswa = '$id_siswa' LIMIT 1");
        
        if ($check_pembayaran && $check_pembayaran->num_rows > 0) {
            $_SESSION['flash_message'] = [
                'type' => 'danger',
                'message' => "❌ Tidak dapat menghapus siswa karena memiliki data pembayaran!"
            ];
        } else {
            $conn->begin_transaction();
            
            try {
                // 1. Hapus dari tabel users
                $conn->query("DELETE FROM users WHERE id_siswa = '$id_siswa'");
                
                // 2. Hapus dari tabel siswa
                $sql = "DELETE FROM siswa WHERE id_siswa = '$id_siswa'";
                if (!$conn->query($sql)) {
                    throw new Exception("Gagal menghapus data siswa: " . $conn->error);
                }
                
                $conn->commit();
                
                $_SESSION['flash_message'] = [
                    'type' => 'success',
                    'message' => "✅ Data siswa dan akun login berhasil dihapus!"
                ];
                
            } catch (Exception $e) {
                $conn->rollback();
                $_SESSION['flash_message'] = [
                    'type' => 'danger',
                    'message' => "❌ Gagal menghapus data: " . $e->getMessage()
                ];
            }
        }
        
        header("Location: siswa.php");
        exit;
    }
}

// ============ HANDLE RESET PASSWORD ============
if (isset($_POST['reset_password'])) {
    $id_siswa = (int)$_POST['id_siswa'];
    
    if ($id_siswa) {
        // Ambil NISN siswa
        $result = $conn->query("SELECT nisn FROM siswa WHERE id_siswa = '$id_siswa'");
        if ($result && $row = $result->fetch_assoc()) {
            $nisn = $row['nisn'];
            $hashed_password = password_hash($nisn, PASSWORD_DEFAULT);
            
            $sql = "UPDATE users SET password = '$hashed_password' WHERE id_siswa = '$id_siswa' AND role = 'siswa'";
            
            if ($conn->query($sql)) {
                $_SESSION['flash_message'] = [
                    'type' => 'success',
                    'message' => "✅ Password berhasil direset ke NISN"
                ];
            } else {
                $_SESSION['flash_message'] = [
                    'type' => 'danger',
                    'message' => "❌ Gagal mereset password"
                ];
            }
        }
        
        header("Location: siswa.php");
        exit;
    }
}

// ============ AMBIL DATA UNTUK NOTIFIKASI ============
$flash_message = $_SESSION['flash_message'] ?? null;
unset($_SESSION['flash_message']);

// ============ FILTER DAN PENCARIAN ============
$filter_kelas = isset($_GET['filter_kelas']) ? (int)$_GET['filter_kelas'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Query untuk mendapatkan data siswa
$sql = "SELECT s.*, k.nama_kelas 
        FROM siswa s 
        JOIN kelas k ON s.id_kelas = k.id_kelas 
        WHERE 1=1";

if (!empty($filter_kelas)) {
    $sql .= " AND s.id_kelas = '$filter_kelas'";
}

if (!empty($search)) {
    $search = $conn->real_escape_string($search);
    $sql .= " AND (s.nisn LIKE '%$search%' OR s.nama_siswa LIKE '%$search%' OR s.no_telp LIKE '%$search%')";
}

$sql .= " ORDER BY s.nama_siswa";
$siswa = $conn->query($sql);

// Ambil data kelas untuk dropdown
$kelas = $conn->query("SELECT * FROM kelas ORDER BY nama_kelas");
$kelas_list = [];
while ($row = $kelas->fetch_assoc()) {
    $kelas_list[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Siswa - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            margin: 0 2px;
        }
        .badge-username {
            background: #e3f2fd;
            color: #0d47a1;
            font-size: 11px;
        }
        .btn-group {
            gap: 3px;
        }
        .table th {
            background-color: #f8f9fa;
            white-space: nowrap;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- MAIN CONTENT -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- Notifikasi Flash -->
            <?php if ($flash_message): ?>
                <div class="alert alert-<?php echo $flash_message['type']; ?> alert-dismissible fade show" role="alert">
                    <i class="bi bi-<?php echo $flash_message['type'] == 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill'; ?> me-2"></i>
                    <?php echo $flash_message['message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- HEADER SECTION -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="mb-1"><i class="bi bi-people-fill me-2"></i> Data Siswa</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Data Siswa</li>
                        </ol>
                    </nav>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahSiswaModal">
                    <i class="bi bi-plus-circle me-2"></i>Tambah Siswa
                </button>
            </div>

            <!-- SEARCH & FILTER SECTION -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-5">
                            <label for="search" class="form-label">
                                <i class="bi bi-search"></i> Pencarian
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="search" name="search" 
                                       placeholder="Cari NISN, Nama, atau No. Telepon..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="bi bi-search"></i> Cari
                                </button>
                                <?php if (!empty($search) || !empty($filter_kelas)): ?>
                                <a href="siswa.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Reset
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label for="filter_kelas" class="form-label">
                                <i class="bi bi-funnel"></i> Filter Kelas
                            </label>
                            <select class="form-select" id="filter_kelas" name="filter_kelas" onchange="this.form.submit()">
                                <option value="">-- Semua Kelas --</option>
                                <?php foreach ($kelas_list as $kelas_row): ?>
                                <option value="<?= $kelas_row['id_kelas']; ?>" <?= $filter_kelas == $kelas_row['id_kelas'] ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($kelas_row['nama_kelas']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="text-muted">
                                <i class="bi bi-info-circle"></i> 
                                Total: <strong><?= $siswa->num_rows; ?></strong> siswa
                                <?php if (!empty($search) || !empty($filter_kelas)): ?>
                                    <span class="badge bg-info ms-2">Filter Aktif</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- DATA TABLE -->
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-table me-2"></i>Daftar Siswa
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="12%">NISN</th>
                                    <th width="18%">Nama Siswa</th>
                                    <th width="10%">Jenis Kelamin</th>
                                    <th width="10%">Kelas</th>
                                    <th width="12%">Telepon</th>
                                    <th width="15%">Tanggal Lahir</th>
                                    <th width="18%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ($siswa && $siswa->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $siswa->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark"><?= htmlspecialchars($row['nisn']); ?></span>
                                        <small class="d-block badge-username mt-1">
                                            <i class="bi bi-person"></i> Username: <?= $row['nisn']; ?>
                                        </small>
                                    </td>
                                    <td class="fw-bold"><?= htmlspecialchars($row['nama_siswa']); ?></td>
                                    <td>
                                        <?php if($row['jenis_kelamin'] == 'L'): ?>
                                            <span class="badge bg-primary">Laki-laki</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Perempuan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($row['nama_kelas']); ?></span></td>
                                    <td>
                                        <?php if($row['no_telp']): ?>
                                            <?= htmlspecialchars($row['no_telp']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($row['tanggal_lahir']): ?>
                                            <?= date('d/m/Y', strtotime($row['tanggal_lahir'])); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="action-buttons">
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-warning" 
                                                    onclick="editSiswa(<?= htmlspecialchars(json_encode($row)); ?>)"
                                                    data-bs-toggle="modal" data-bs-target="#editSiswaModal"
                                                    title="Edit data siswa">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-info" 
                                                    onclick="showLoginInfo('<?= htmlspecialchars($row['nisn']); ?>', '<?= htmlspecialchars($row['nama_siswa']); ?>')"
                                                    title="Lihat informasi login">
                                                <i class="bi bi-key"></i>
                                            </button>
                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Reset password <?= htmlspecialchars($row['nama_siswa']); ?> ke NISN?')">
                                                <input type="hidden" name="id_siswa" value="<?= $row['id_siswa']; ?>">
                                                <button type="submit" name="reset_password" class="btn btn-sm btn-secondary" title="Reset password ke NISN">
                                                    <i class="bi bi-arrow-repeat"></i>
                                                </button>
                                            </form>
                                            <a href="?hapus=<?= $row['id_siswa']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('⚠️ Hapus data siswa <?= htmlspecialchars($row['nama_siswa']); ?>?\n\nAkun login siswa ini juga akan dihapus!\nData yang dihapus tidak dapat dikembalikan.')"
                                               title="Hapus siswa">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-5">
                                        <i class="bi bi-people display-1 text-muted"></i>
                                        <h5 class="mt-3 text-muted">
                                            <?php if (!empty($search) || !empty($filter_kelas)): ?>
                                                Tidak ada data siswa yang sesuai dengan kriteria pencarian
                                            <?php else: ?>
                                                Belum ada data siswa
                                            <?php endif; ?>
                                        </h5>
                                        <?php if (!empty($search) || !empty($filter_kelas)): ?>
                                        <a href="siswa.php" class="btn btn-outline-primary mt-3">
                                            <i class="bi bi-arrow-left"></i> Kembali ke semua data
                                        </a>
                                        <?php else: ?>
                                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#tambahSiswaModal">
                                            <i class="bi bi-plus-circle"></i> Tambah Siswa Pertama
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- INFORMASI SISTEM -->
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="fw-bold text-primary">
                                <i class="bi bi-info-circle-fill me-2"></i>
                                Informasi Akun Siswa
                            </h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <ul class="mb-0 small">
                                        <li class="mb-2">✅ Setiap siswa otomatis dibuatkan akun login saat ditambahkan</li>
                                        <li class="mb-2">✅ Username = NISN, Password = NISN</li>
                                        <li class="mb-2">✅ Siswa dapat login di halaman login dengan role "siswa"</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul class="mb-0 small">
                                        <li class="mb-2">✅ Admin dapat mereset password dengan tombol <span class="badge bg-secondary">↻</span></li>
                                        <li class="mb-2">⚠️ Hapus siswa akan otomatis menghapus akun loginnya</li>
                                        <li class="mb-2">⚠️ Siswa dengan data pembayaran tidak dapat dihapus</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- MODAL TAMBAH SISWA -->
<div class="modal fade" id="tambahSiswaModal" tabindex="-1" aria-labelledby="tambahSiswaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="tambahSiswaModalLabel">
                    <i class="bi bi-plus-circle me-2"></i>Tambah Data Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="" onsubmit="return validateForm()">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        <strong>Informasi Login:</strong> Siswa akan otomatis dibuatkan akun dengan username dan password = NISN
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="nisn" class="form-label fw-bold">NISN <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nisn" name="nisn" required 
                                       pattern="[0-9]+" title="Hanya angka diperbolehkan" maxlength="20">
                                <div class="form-text">Minimal 10 digit angka</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="nama_siswa" class="form-label fw-bold">Nama Siswa <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Jenis Kelamin <span class="text-danger">*</span></label>
                                <div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki" value="L" required>
                                        <label class="form-check-label" for="laki">Laki-laki</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="P" required>
                                        <label class="form-check-label" for="perempuan">Perempuan</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="id_kelas" class="form-label fw-bold">Kelas <span class="text-danger">*</span></label>
                                <select class="form-select" id="id_kelas" name="id_kelas" required>
                                    <option value="">-- Pilih Kelas --</option>
                                    <?php foreach ($kelas_list as $kelas_row): ?>
                                        <option value="<?= $kelas_row['id_kelas']; ?>">
                                            <?= htmlspecialchars($kelas_row['nama_kelas']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_lahir" class="form-label fw-bold">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
                                <div class="form-text">Opsional</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="no_telp" class="form-label fw-bold">Nomor Telepon</label>
                                <input type="tel" class="form-control" id="no_telp" name="no_telp" 
                                       pattern="[0-9+\-\s]+" title="Hanya angka, tanda plus, minus dan spasi diperbolehkan">
                                <div class="form-text">Opsional</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="alamat" class="form-label fw-bold">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="2"></textarea>
                        <div class="form-text">Opsional</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x"></i> Batal
                    </button>
                    <button type="submit" name="tambah_siswa" class="btn btn-primary">
                        <i class="bi bi-save"></i> Simpan & Buat Akun
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDIT SISWA -->
<div class="modal fade" id="editSiswaModal" tabindex="-1" aria-labelledby="editSiswaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="editSiswaModalLabel">
                    <i class="bi bi-pencil-square me-2"></i>Edit Data Siswa
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="" id="editForm">
                <input type="hidden" name="id_siswa" id="edit_id_siswa">
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <strong>Perhatian:</strong> Jika NISN diubah, username login siswa juga akan berubah!
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_nisn" class="form-label fw-bold">NISN <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_nisn" name="nisn" required 
                                       pattern="[0-9]+" title="Hanya angka diperbolehkan" maxlength="20">
                                <div class="form-text">Username login siswa</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_nama_siswa" class="form-label fw-bold">Nama Siswa <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_nama_siswa" name="nama_siswa" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Jenis Kelamin <span class="text-danger">*</span></label>
                                <div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="edit_laki" value="L" required>
                                        <label class="form-check-label" for="edit_laki">Laki-laki</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="edit_perempuan" value="P" required>
                                        <label class="form-check-label" for="edit_perempuan">Perempuan</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_id_kelas" class="form-label fw-bold">Kelas <span class="text-danger">*</span></label>
                                <select class="form-select" id="edit_id_kelas" name="id_kelas" required>
                                    <option value="">-- Pilih Kelas --</option>
                                    <?php foreach ($kelas_list as $kelas_row): ?>
                                        <option value="<?= $kelas_row['id_kelas']; ?>">
                                            <?= htmlspecialchars($kelas_row['nama_kelas']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_tanggal_lahir" class="form-label fw-bold">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="edit_tanggal_lahir" name="tanggal_lahir">
                                <div class="form-text">Opsional</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_no_telp" class="form-label fw-bold">Nomor Telepon</label>
                                <input type="tel" class="form-control" id="edit_no_telp" name="no_telp">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_alamat" class="form-label fw-bold">Alamat</label>
                        <textarea class="form-control" id="edit_alamat" name="alamat" rows="2"></textarea>
                        <div class="form-text">Opsional</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x"></i> Batal
                    </button>
                    <button type="submit" name="edit_siswa" class="btn btn-warning">
                        <i class="bi bi-save"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL INFORMASI LOGIN -->
<div class="modal fade" id="loginInfoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">
                    <i class="bi bi-key-fill me-2"></i>Informasi Akun Login
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <i class="bi bi-person-circle display-1 text-info"></i>
                </div>
                <table class="table table-borderless">
                    <tr>
                        <td width="40%"><strong>Nama Siswa</strong></td>
                        <td><span id="info_nama" class="fw-bold"></span></td>
                    </tr>
                    <tr>
                        <td><strong>Username</strong></td>
                        <td><span id="info_username" class="fw-bold text-primary"></span></td>
                    </tr>
                    <tr>
                        <td><strong>Password</strong></td>
                        <td>
                            <span id="info_password" class="fw-bold text-success"></span>
                            <span class="badge bg-warning ms-2">Default</span>
                        </td>
                    </tr>
                </table>
                <div class="alert alert-info mt-3">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    Siswa dapat login menggunakan NISN sebagai username dan password.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x"></i> Tutup
                </button>
            </div>
        </div>
    </div>
</div>

<?php 
$conn->close(); 
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Function untuk mengisi form edit
function editSiswa(data) {
    document.getElementById('edit_id_siswa').value = data.id_siswa;
    document.getElementById('edit_nisn').value = data.nisn;
    document.getElementById('edit_nama_siswa').value = data.nama_siswa;
    document.getElementById('edit_no_telp').value = data.no_telp || '';
    document.getElementById('edit_alamat').value = data.alamat || '';
    document.getElementById('edit_tanggal_lahir').value = data.tanggal_lahir || '';
    
    // Set radio button jenis kelamin
    if (data.jenis_kelamin === 'L') {
        document.getElementById('edit_laki').checked = true;
    } else {
        document.getElementById('edit_perempuan').checked = true;
    }
    
    // Set select kelas
    document.getElementById('edit_id_kelas').value = data.id_kelas;
}

// Function untuk menampilkan informasi login
function showLoginInfo(nisn, nama) {
    document.getElementById('info_nama').innerHTML = nama;
    document.getElementById('info_username').innerHTML = nisn;
    document.getElementById('info_password').innerHTML = nisn;
    
    var loginModal = new bootstrap.Modal(document.getElementById('loginInfoModal'));
    loginModal.show();
}

// Validasi form tambah siswa
function validateForm() {
    var nisn = document.getElementById('nisn').value.trim();
    var nama = document.getElementById('nama_siswa').value.trim();
    
    if (nisn === '') {
        alert('NISN harus diisi!');
        document.getElementById('nisn').focus();
        return false;
    }
    
    if (nisn.length < 10) {
        alert('NISN minimal 10 digit!');
        document.getElementById('nisn').focus();
        return false;
    }
    
    if (!/^\d+$/.test(nisn)) {
        alert('NISN hanya boleh berisi angka!');
        document.getElementById('nisn').focus();
        return false;
    }
    
    if (nama === '') {
        alert('Nama siswa harus diisi!');
        document.getElementById('nama_siswa').focus();
        return false;
    }
    
    return true;
}

// Auto hide alert setelah 5 detik
setTimeout(function() {
    var alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        var bsAlert = new bootstrap.Alert(alert);
        setTimeout(function() {
            bsAlert.close();
        }, 5000);
    });
}, 100);
</script>
</body>
</html>