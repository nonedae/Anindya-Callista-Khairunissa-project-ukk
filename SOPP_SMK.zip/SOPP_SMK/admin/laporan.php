<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

// ================ FILTER ================
$bulan = $_GET['bulan'] ?? date('F');
$tahun = $_GET['tahun'] ?? date('Y');
$kelas = $_GET['kelas'] ?? '';

// ================ BULAN & TAHUN LIST ================
$bulan_list = getBulanList();
$tahun_list = getTahunList();
$kelas_list = $conn->query("SELECT * FROM kelas ORDER BY tingkat, nama_kelas");

// ================ BUILD WHERE CLAUSE ================
$where = "WHERE p.bulan = '$bulan' AND p.tahun = '$tahun'";
if ($kelas != '') {
    $where .= " AND s.id_kelas = $kelas";
}

// ================ GET LAPORAN PEMBAYARAN ================
$laporan = $conn->query("
    SELECT p.*, s.nama_siswa, s.nisn, k.nama_kelas 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    $where 
    ORDER BY k.nama_kelas, s.nama_siswa
");

// ================ GET STATISTIK ================
$statistik = $conn->query("
    SELECT 
        COUNT(*) as total_transaksi,
        COALESCE(SUM(p.jumlah), 0) as total_pendapatan,
        COUNT(DISTINCT p.id_siswa) as total_siswa_bayar
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    $where
")->fetch_assoc();

// ================ GET SISWA BELUM BAYAR ================
$query_belum = "
    SELECT s.*, k.nama_kelas 
    FROM siswa s 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    WHERE s.id_siswa NOT IN (
        SELECT p.id_siswa FROM pembayaran p 
        WHERE p.bulan = '$bulan' AND p.tahun = '$tahun'
    )
";

if ($kelas != '') {
    $query_belum .= " AND s.id_kelas = $kelas";
}

$query_belum .= " ORDER BY k.nama_kelas, s.nama_siswa";
$belum_bayar = $conn->query($query_belum);

// ================ GET TOTAL SISWA PER KELAS ================
$total_siswa_query = "SELECT COUNT(*) as total FROM siswa";
if ($kelas != '') {
    $total_siswa_query .= " WHERE id_kelas = $kelas";
}
$total_siswa = $conn->query($total_siswa_query)->fetch_assoc()['total'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
        }
        .stat-card {
            border-radius: 15px;
            padding: 25px;
            color: white;
            height: 100%;
        }
        .stat-card-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-card-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .stat-card-warning { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-card-info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        
        @media print {
            .no-print { display: none !important; }
            .print-only { display: block !important; }
            .card { box-shadow: none; border: 1px solid #ddd; }
            body { background: white; }
        }
        .print-only { display: none; }
        
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-4 no-print">
                <div>
                    <h3 class="fw-bold text-primary">
                        <i class="bi bi-file-text"></i> Laporan Pembayaran SOPP
                    </h3>
                    <p class="text-muted">
                        Periode: <?php echo $bulan . ' ' . $tahun; ?>
                        <?php if ($kelas != ''): ?>
                            <?php 
                            $kelas_info = $conn->query("SELECT nama_kelas FROM kelas WHERE id_kelas = $kelas")->fetch_assoc(); 
                            ?>
                            | Kelas: <?php echo $kelas_info['nama_kelas']; ?>
                        <?php else: ?>
                            | Semua Kelas
                        <?php endif; ?>
                    </p>
                </div>
                <div>
                    <button onclick="window.print()" class="btn btn-success">
                        <i class="bi bi-printer"></i> Cetak Laporan
                    </button>
                </div>
            </div>

            <!-- PRINT HEADER -->
            <div class="print-only mb-4">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h2>SMKN 1 DLANGGU</h2>
                    <h4>Sistem Pembayaran SOPP</h4>
                    <p>Jl. A. Yani No 01, Ds. Pohkecik, Mojokerto</p>
                    <hr style="border-top: 2px solid #000;">
                    <h3>LAPORAN PEMBAYARAN SOPP</h3>
                    <table style="width: 100%; margin-top: 20px;">
                        <tr>
                            <td style="width: 20%;"><strong>Periode</strong></td>
                            <td style="width: 5%;">:</td>
                            <td style="width: 75%;"><?php echo $bulan . ' ' . $tahun; ?></td>
                        </tr>
                        <tr>
                            <td><strong>Kelas</strong></td>
                            <td>:</td>
                            <td>
                                <?php 
                                if ($kelas != '') {
                                    $kelas_info = $conn->query("SELECT nama_kelas FROM kelas WHERE id_kelas = $kelas")->fetch_assoc();
                                    echo $kelas_info['nama_kelas'];
                                } else {
                                    echo 'Semua Kelas';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Tanggal Cetak</strong></td>
                            <td>:</td>
                            <td><?php echo date('d F Y'); ?></td>
                        </tr>
                    </table>
                    <hr style="border-top: 1px solid #000;">
                </div>
            </div>

            <!-- FILTER SECTION -->
            <div class="card mb-4 no-print">
                <div class="card-header bg-white">
                    <i class="bi bi-funnel"></i> Filter Laporan
                </div>
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Bulan</label>
                            <select name="bulan" class="form-select">
                                <?php foreach($bulan_list as $bln): ?>
                                <option value="<?= $bln ?>" <?= $bulan == $bln ? 'selected' : '' ?>>
                                    <?= $bln ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Tahun</label>
                            <select name="tahun" class="form-select">
                                <?php foreach($tahun_list as $thn): ?>
                                <option value="<?= $thn ?>" <?= $tahun == $thn ? 'selected' : '' ?>>
                                    <?= $thn ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Kelas</label>
                            <select name="kelas" class="form-select">
                                <option value="">-- Semua Kelas --</option>
                                <?php 
                                $kelas_list->data_seek(0);
                                while($k = $kelas_list->fetch_assoc()): 
                                ?>
                                <option value="<?= $k['id_kelas'] ?>" <?= $kelas == $k['id_kelas'] ? 'selected' : '' ?>>
                                    <?= $k['nama_kelas'] ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Tampilkan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- STATISTIK CARD -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card stat-card-primary">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Total Pendapatan</h6>
                                <h2 class="display-6 text-white">
                                    <?php echo formatRupiah($statistik['total_pendapatan'] ?? 0); ?>
                                </h2>
                                <small>Bulan <?php echo $bulan . ' ' . $tahun; ?></small>
                            </div>
                            <i class="bi bi-cash-stack fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="stat-card stat-card-success">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Siswa Sudah Bayar</h6>
                                <h2 class="display-6 text-white">
                                    <?php echo $statistik['total_siswa_bayar'] ?? 0; ?>
                                </h2>
                                <small>Dari <?php echo $total_siswa; ?> siswa</small>
                            </div>
                            <i class="bi bi-check-circle-fill fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="stat-card stat-card-warning">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Siswa Belum Bayar</h6>
                                <h2 class="display-6 text-white">
                                    <?php echo $belum_bayar->num_rows; ?>
                                </h2>
                                <small>Siswa</small>
                            </div>
                            <i class="bi bi-x-circle-fill fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DAFTAR SISWA BELUM BAYAR -->
            <?php if ($belum_bayar->num_rows > 0): ?>
            <div class="card mb-4 border-warning">
                <div class="card-header bg-warning text-dark">
                    <i class="bi bi-exclamation-triangle-fill"></i> 
                    Siswa Belum Bayar - <?php echo $bulan . ' ' . $tahun; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NISN</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    <th>Telepon</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php while($row = $belum_bayar->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $row['nisn']; ?></td>
                                    <td><?php echo $row['nama_siswa']; ?></td>
                                    <td><?php echo $row['nama_kelas']; ?></td>
                                    <td><?php echo $row['no_telp'] ?? '-'; ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- TABEL LAPORAN PEMBAYARAN -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-table"></i> Data Pembayaran - <?php echo $bulan . ' ' . $tahun; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="12%">NISN</th>
                                    <th width="20%">Nama Siswa</th>
                                    <th width="10%">Kelas</th>
                                    <th width="12%">Tanggal Bayar</th>
                                    <th width="15%">Bulan/Tahun</th>
                                    <th width="15%">Jumlah</th>
                                    <th width="15%">No. Kwitansi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($laporan && $laporan->num_rows > 0): ?>
                                    <?php $no = 1; ?>
                                    <?php while($row = $laporan->fetch_assoc()): ?>
                                    <tr>
                                        <td class="text-center"><?php echo $no++; ?></td>
                                        <td><?php echo $row['nisn']; ?></td>
                                        <td><?php echo $row['nama_siswa']; ?></td>
                                        <td><?php echo $row['nama_kelas']; ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($row['tanggal_bayar'])); ?></td>
                                        <td><?php echo $row['bulan'] . ' ' . $row['tahun']; ?></td>
                                        <td class="fw-bold text-success"><?php echo formatRupiah($row['jumlah']); ?></td>
                                        <td><small><?php echo $row['no_kwitansi']; ?></small></td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-5">
                                            <i class="bi bi-cash-coin display-4 text-muted"></i>
                                            <h5 class="mt-3 text-muted">
                                                Belum ada data pembayaran untuk periode <?php echo $bulan . ' ' . $tahun; ?>
                                            </h5>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <th colspan="6" class="text-end">Total:</th>
                                    <th class="text-success">
                                        <?php echo formatRupiah($statistik['total_pendapatan'] ?? 0); ?>
                                    </th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- FOOTER PRINT -->
            <div class="print-only" style="margin-top: 50px;">
                <table style="width: 100%;">
                    <tr>
                        <td style="width: 60%;"></td>
                        <td style="width: 40%; text-align: center;">
                            <p>Mojokerto, <?php echo date('d F Y'); ?></p>
                            <p>Kepala Sekolah,</p>
                            <br><br><br>
                            <p style="text-decoration: underline;">Drs. H. SUPRAPTO, M.Pd</p>
                            <p>NIP. 196512311990031012</p>
                        </td>
                    </tr>
                </table>
            </div>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto submit filter
    document.querySelectorAll('select[name="bulan"], select[name="tahun"], select[name="kelas"]').forEach(select => {
        select.addEventListener('change', function() {
            this.form.submit();
        });
    });
</script>
</body>
</html>