<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

$pesan = '';
$aksi = $_GET['aksi'] ?? '';
$id = $_GET['id'] ?? 0;

// ================ HANDLE PENCARIAN ================
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// ================ HAPUS GURU ================
if ($aksi == 'hapus' && $id > 0) {
    // Ambil user_id dulu untuk dihapus dari tabel users
    $result = $conn->query("SELECT user_id FROM guru WHERE id_guru = $id");
    $guru_data = $result ? $result->fetch_assoc() : null;
    $user_id = $guru_data['user_id'] ?? 0;
    
    $cek = $conn->query("SELECT * FROM wali_kelas WHERE id_guru = $id");
    if ($cek && $cek->num_rows > 0) {
        $pesan = '<div class="alert alert-danger">❌ Guru ini menjadi wali kelas, tidak bisa dihapus!</div>';
    } else {
        $conn->query("DELETE FROM guru WHERE id_guru = $id");
        if ($user_id > 0) {
            $conn->query("DELETE FROM users WHERE id_user = $user_id");
        }
        $pesan = '<div class="alert alert-success">✅ Data guru berhasil dihapus!</div>';
    }
}

// ================ TAMBAH/EDIT GURU ================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_guru = $_POST['id_guru'] ?? 0;
    $nip = trim($_POST['nip']);
    $nama_guru = trim($_POST['nama_guru']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $email = trim($_POST['email'] ?? '');
    $no_telp = trim($_POST['no_telp'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // ================ EDIT GURU ================
    if ($id_guru > 0) {
        // Update data guru
        $stmt = $conn->prepare("UPDATE guru SET nip=?, nama_guru=?, jenis_kelamin=?, email=?, no_telp=? WHERE id_guru=?");
        $stmt->bind_param("sssssi", $nip, $nama_guru, $jenis_kelamin, $email, $no_telp, $id_guru);
        
        if ($stmt->execute()) {
            $pesan = '<div class="alert alert-success">✅ Data guru berhasil diperbarui!</div>';
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'guru.php';
                }, 2000);
            </script>";
        } else {
            $pesan = '<div class="alert alert-danger">❌ Gagal memperbarui data: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    } 
    // ================ TAMBAH GURU BARU ================
    else {
        // Validasi input tidak boleh kosong
        if (empty($nip) || empty($nama_guru) || empty($jenis_kelamin) || empty($username) || empty($password)) {
            $pesan = '<div class="alert alert-danger">❌ Semua field wajib harus diisi!</div>';
        }
        // Cek apakah NIP sudah terdaftar
        else {
            $cek = $conn->query("SELECT id_guru FROM guru WHERE nip = '$nip'");
            if ($cek && $cek->num_rows > 0) {
                $pesan = '<div class="alert alert-danger">❌ NIP sudah terdaftar!</div>';
            } 
            // Cek apakah username sudah digunakan
            elseif ($conn->query("SELECT id_user FROM users WHERE username = '$username'")->num_rows > 0) {
                $pesan = '<div class="alert alert-danger">❌ Username sudah digunakan!</div>';
            }
            else {
                // Buat user account dulu
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $role = 'wali_kelas'; // Definisikan role DI SINI sebelum digunakan
                
                // Insert ke tabel users - HANYA username, password, role
                $stmt_user = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
                $stmt_user->bind_param("sss", $username, $hashed_password, $role);
                
                if ($stmt_user->execute()) {
                    $user_id = $stmt_user->insert_id;
                    $stmt_user->close();
                    
                    // Insert ke tabel guru
                    $stmt_guru = $conn->prepare("INSERT INTO guru (nip, nama_guru, jenis_kelamin, email, no_telp, user_id) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_guru->bind_param("sssssi", $nip, $nama_guru, $jenis_kelamin, $email, $no_telp, $user_id);
                    
                    if ($stmt_guru->execute()) {
                        $pesan = '<div class="alert alert-success">✅ Data guru berhasil ditambahkan! Username: <strong>' . $username . '</strong></div>';
                        echo "<script>
                            setTimeout(function() {
                                window.location.href = 'guru.php';
                            }, 2000);
                        </script>";
                    } else {
                        // Rollback: hapus user jika insert guru gagal
                        $conn->query("DELETE FROM users WHERE id_user = $user_id");
                        $pesan = '<div class="alert alert-danger">❌ Gagal menambahkan data guru: ' . $stmt_guru->error . '</div>';
                    }
                    $stmt_guru->close();
                } else {
                    $pesan = '<div class="alert alert-danger">❌ Gagal membuat akun: ' . $stmt_user->error . '</div>';
                }
            }
        }
    }
}

// ================ AMBIL DATA GURU (DENGAN PENCARIAN) ================
if (!empty($search)) {
    $guru = $conn->query("
        SELECT * FROM guru 
        WHERE nip LIKE '%$search%' 
           OR nama_guru LIKE '%$search%' 
           OR email LIKE '%$search%' 
           OR no_telp LIKE '%$search%'
        ORDER BY nama_guru
    ");
} else {
    $guru = $conn->query("SELECT * FROM guru ORDER BY nama_guru");
}

// ================ AMBIL DATA GURU UNTUK EDIT ================
$guru_edit = null;
if ($aksi == 'edit' && $id > 0) {
    $result = $conn->query("SELECT * FROM guru WHERE id_guru = $id");
    $guru_edit = $result ? $result->fetch_assoc() : null;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Guru - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .search-box {
            background: white;
            border-radius: 8px;
            padding: 15px;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .badge-role {
            background-color: #17a2b8;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3><i class="bi bi-person-badge me-2"></i> Data Guru</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Data Guru</li>
                        </ol>
                    </nav>
                </div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#guruModal">
                    <i class="bi bi-plus-circle me-2"></i> Tambah Guru
                </button>
            </div>

            <!-- Pesan Notifikasi -->
            <?= $pesan ?>

            <!-- Form Pencarian -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label"><i class="bi bi-search"></i> Pencarian</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Cari berdasarkan NIP, Nama Guru, Email, atau No. Telepon..." 
                                       value="<?= htmlspecialchars($search) ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="bi bi-search"></i> Cari
                                </button>
                                <?php if (!empty($search)): ?>
                                <a href="guru.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Reset
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><i class="bi bi-info-circle"></i> Informasi</label>
                            <div class="form-control bg-light">
                                <i class="bi bi-people"></i> Total Data: <strong><?= $guru ? $guru->num_rows : 0 ?></strong> guru
                                <?php if (!empty($search)): ?>
                                    <span class="badge bg-info ms-2">Hasil Pencarian</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Data Guru -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="bi bi-table me-2"></i> Daftar Guru
                        <?php if (!empty($search)): ?>
                            <span class="badge bg-info ms-2">Keyword: "<?= htmlspecialchars($search) ?>"</span>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="12%">NIP</th>
                                    <th width="20%">Nama Guru</th>
                                    <th width="10%">JK</th>
                                    <th width="20%">Email</th>
                                    <th width="15%">Telepon</th>
                                    <th width="18%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ($guru && $guru->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $guru->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($row['nip']) ?></span></td>
                                    <td class="fw-bold"><?= htmlspecialchars($row['nama_guru']) ?></td>
                                    <td>
                                        <?php if($row['jenis_kelamin'] == 'L'): ?>
                                            <span class="badge bg-primary"><i class="bi bi-gender-male"></i> L</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><i class="bi bi-gender-female"></i> P</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($row['email']): ?>
                                            <i class="bi bi-envelope"></i> <?= htmlspecialchars($row['email']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($row['no_telp']): ?>
                                            <i class="bi bi-telephone"></i> <?= htmlspecialchars($row['no_telp']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="?aksi=edit&id=<?= $row['id_guru'] ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                        <a href="?aksi=hapus&id=<?= $row['id_guru'] ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('⚠️ Hapus data guru <?= htmlspecialchars($row['nama_guru']) ?>?\nData guru yang sudah dihapus tidak dapat dikembalikan!')">
                                            <i class="bi bi-trash"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <i class="bi bi-person-badge display-1 text-muted"></i>
                                        <h5 class="mt-3 text-muted">
                                            <?php if (!empty($search)): ?>
                                                Tidak ditemukan data guru dengan kata kunci "<?= htmlspecialchars($search) ?>"
                                            <?php else: ?>
                                                Belum ada data guru
                                            <?php endif; ?>
                                        </h5>
                                        <?php if (!empty($search)): ?>
                                        <a href="guru.php" class="btn btn-outline-primary mt-3">
                                            <i class="bi bi-arrow-left"></i> Tampilkan semua data
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- Modal Tambah/Edit Guru -->
<div class="modal fade" id="guruModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header <?= $guru_edit ? 'bg-warning' : 'bg-primary' ?> text-white">
                <h5 class="modal-title">
                    <i class="bi <?= $guru_edit ? 'bi-pencil-square' : 'bi-plus-circle' ?> me-2"></i>
                    <?= $guru_edit ? 'Edit' : 'Tambah' ?> Data Guru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="id_guru" value="<?= $guru_edit['id_guru'] ?? '' ?>">
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">NIP <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nip" 
                                   value="<?= htmlspecialchars($guru_edit['nip'] ?? '') ?>" 
                                   required maxlength="20" pattern="[0-9]+" title="Hanya angka">
                            <div class="form-text">Nomor Induk Pegawai (hanya angka)</div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nama Guru <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nama_guru" 
                                   value="<?= htmlspecialchars($guru_edit['nama_guru'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select class="form-select" name="jenis_kelamin" required>
                                <option value="">-- Pilih --</option>
                                <option value="L" <?= ($guru_edit['jenis_kelamin'] ?? '') == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                                <option value="P" <?= ($guru_edit['jenis_kelamin'] ?? '') == 'P' ? 'selected' : '' ?>>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?= htmlspecialchars($guru_edit['email'] ?? '') ?>">
                            <div class="form-text">Contoh: nama@gmail.com</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">No. Telepon</label>
                        <input type="text" class="form-control" name="no_telp" 
                               value="<?= htmlspecialchars($guru_edit['no_telp'] ?? '') ?>"
                               pattern="[0-9+\-\s]+" title="Hanya angka, tanda plus, minus dan spasi">
                        <div class="form-text">Contoh: 081234567890</div>
                    </div>

                    <?php if (!$guru_edit): ?>
                    <hr class="my-3">
                    <h6 class="fw-bold text-primary"><i class="bi bi-shield-lock"></i> Informasi Akun Login</h6>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Username <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="username" required 
                                   minlength="4" maxlength="50">
                            <div class="form-text">Minimal 4 karakter</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="password" required 
                                   minlength="6">
                            <div class="form-text">Minimal 6 karakter</div>
                        </div>
                    </div>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> Guru akan dapat login dengan username dan password yang dibuat.
                    </div>
                    <?php endif; ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x"></i> Batal
                    </button>
                    <button type="submit" class="btn <?= $guru_edit ? 'btn-warning' : 'btn-primary' ?>">
                        <i class="bi bi-save"></i> <?= $guru_edit ? 'Update' : 'Simpan' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php 
// ================ TUTUP KONEKSI DI PALING BAWAH ================
$conn->close(); 
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script untuk menampilkan modal edit -->
<?php if ($guru_edit): ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var myModal = new bootstrap.Modal(document.getElementById('guruModal'));
    myModal.show();
});
</script>
<?php endif; ?>

</body>
</html>