<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

$pesan = '';
$aksi  = $_GET['aksi'] ?? '';
$id    = (int)($_GET['id'] ?? 0);

// ================= HAPUS WALI KELAS =================
if ($aksi === 'hapus' && $id > 0) {
    $stmt = $conn->prepare("DELETE FROM wali_kelas WHERE id_wali_kelas=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    $pesan = '<div class="alert alert-success">✅ Wali kelas berhasil dihapus!</div>';
}

// ================= SET WALI KELAS =================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_wali'])) {
    $id_guru      = (int)$_POST['id_guru'];
    $id_kelas     = (int)$_POST['id_kelas'];
    $tahun_ajaran = $_POST['tahun_ajaran'];

    // CEK 1: Apakah kelas sudah punya wali?
    $cek_kelas = $conn->prepare("SELECT id_wali_kelas FROM wali_kelas WHERE id_kelas=?");
    $cek_kelas->bind_param("i", $id_kelas);
    $cek_kelas->execute();
    $cek_kelas->store_result();

    // CEK 2: Apakah guru sudah menjadi wali kelas di kelas lain?
    $cek_guru = $conn->prepare("SELECT id_wali_kelas FROM wali_kelas WHERE id_guru=?");
    $cek_guru->bind_param("i", $id_guru);
    $cek_guru->execute();
    $cek_guru->store_result();

    $kelas_sudah_ada_wali = $cek_kelas->num_rows > 0;
    $guru_sudah_jadi_wali = $cek_guru->num_rows > 0;

    if ($kelas_sudah_ada_wali) {
        $pesan = '<div class="alert alert-danger">❌ Kelas ini sudah memiliki wali kelas!</div>';
    } elseif ($guru_sudah_jadi_wali) {
        // Ambil informasi kelas yang sudah dipegang guru ini
        $guru_info = $conn->prepare("
            SELECT k.nama_kelas 
            FROM wali_kelas wk
            JOIN kelas k ON wk.id_kelas = k.id_kelas
            WHERE wk.id_guru = ?
        ");
        $guru_info->bind_param("i", $id_guru);
        $guru_info->execute();
        $result = $guru_info->get_result();
        $kelas_dipegang = $result->fetch_assoc();
        $guru_info->close();
        
        $pesan = '<div class="alert alert-warning">
                    ⚠️ Guru ini <strong>sudah menjadi wali kelas</strong> di kelas <strong>' . $kelas_dipegang['nama_kelas'] . '</strong>!<br>
                    <small class="text-muted">Seorang guru hanya boleh menjadi wali kelas di SATU kelas.</small>
                  </div>';
    } else {
        // Lolos semua pengecekan, boleh insert
        $stmt = $conn->prepare("INSERT INTO wali_kelas (id_guru, id_kelas, tahun_ajaran) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $id_guru, $id_kelas, $tahun_ajaran);
        if ($stmt->execute()) {
            $pesan = '<div class="alert alert-success">✅ Wali kelas berhasil ditetapkan!</div>';
        } else {
            $pesan = '<div class="alert alert-danger">❌ Gagal menetapkan wali kelas: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    }
    
    $cek_kelas->close();
    $cek_guru->close();
}

// ================= AMBIL DATA UNTUK DITAMPILKAN =================
// Ambil daftar guru yang BELUM menjadi wali kelas
$guru_belum_jadi_wali = $conn->query("
    SELECT g.id_guru, g.nama_guru, g.nip
    FROM guru g
    LEFT JOIN wali_kelas wk ON g.id_guru = wk.id_guru
    WHERE wk.id_guru IS NULL
    ORDER BY g.nama_guru
");

// Ambil daftar kelas yang BELUM punya wali
$kelas_tanpa_wali = $conn->query("
    SELECT k.id_kelas, k.nama_kelas, k.tingkat, k.jurusan
    FROM kelas k
    LEFT JOIN wali_kelas wk ON k.id_kelas = wk.id_kelas
    WHERE wk.id_kelas IS NULL
    ORDER BY k.tingkat, k.nama_kelas
");

// Ambil data wali kelas yang sudah ada (untuk ditampilkan di tabel)
$wali_kelas = $conn->query("
    SELECT wk.*, g.nama_guru, g.nip, k.nama_kelas, k.tingkat, k.jurusan
    FROM wali_kelas wk
    JOIN guru g ON wk.id_guru = g.id_guru
    JOIN kelas k ON wk.id_kelas = k.id_kelas
    ORDER BY k.tingkat, k.nama_kelas
");

// ================= AMBIL DATA STATISTIK =================
$total_guru = $conn->query("SELECT COUNT(*) as total FROM guru")->fetch_assoc()['total'];
$total_kelas = $conn->query("SELECT COUNT(*) as total FROM kelas")->fetch_assoc()['total'];
$total_wali = $wali_kelas->num_rows;

// ================= TUTUP KONEKSI DI AKHIR =================
// $conn->close(); // DITUTUP DULU, NANTI DI AKHIR SAJA
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Wali Kelas - <?= APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .card-header {
            font-weight: 600;
        }
        .badge-kelas {
            background-color: #6c757d;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
        }
        .info-box {
            background-color: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- MAIN -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3><i class="bi bi-person-check me-2"></i> Wali Kelas</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Wali Kelas</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <!-- PESAN NOTIFIKASI -->
            <?= $pesan; ?>

            <!-- INFO BOX -->
            <?php if ($guru_belum_jadi_wali && $guru_belum_jadi_wali->num_rows == 0 && $kelas_tanpa_wali && $kelas_tanpa_wali->num_rows > 0): ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle"></i> 
                <strong>Perhatian!</strong> Semua guru sudah menjadi wali kelas. Tidak ada guru yang tersedia untuk ditetapkan.
            </div>
            <?php endif; ?>
            
            <?php if ($guru_belum_jadi_wali && $guru_belum_jadi_wali->num_rows > 0 && $kelas_tanpa_wali && $kelas_tanpa_wali->num_rows == 0): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle"></i> 
                <strong>Lengkap!</strong> Semua kelas sudah memiliki wali kelas.
            </div>
            <?php endif; ?>

            <!-- FORM TETAPKAN WALI KELAS -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-person-plus me-2"></i> Tetapkan Wali Kelas Baru
                </div>
                <div class="card-body">
                    <?php if (!$guru_belum_jadi_wali || !$kelas_tanpa_wali || $guru_belum_jadi_wali->num_rows == 0 || $kelas_tanpa_wali->num_rows == 0): ?>
                        <div class="alert alert-secondary mb-0">
                            <i class="bi bi-info-circle"></i> 
                            <?php if ($guru_belum_jadi_wali && $guru_belum_jadi_wali->num_rows == 0): ?>
                                <strong>Tidak ada guru yang tersedia.</strong> Semua guru sudah menjadi wali kelas.
                            <?php endif; ?>
                            <?php if ($kelas_tanpa_wali && $kelas_tanpa_wali->num_rows == 0): ?>
                                <strong>Tidak ada kelas yang tersedia.</strong> Semua kelas sudah memiliki wali kelas.
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                    <form method="POST" class="row g-3">
                        <input type="hidden" name="set_wali" value="1">
                        
                        <div class="col-md-5">
                            <label class="form-label fw-bold">
                                <i class="bi bi-person"></i> Pilih Guru
                            </label>
                            <select name="id_guru" class="form-select" required>
                                <option value="">-- Pilih Guru --</option>
                                <?php while($g = $guru_belum_jadi_wali->fetch_assoc()): ?>
                                <option value="<?= $g['id_guru']; ?>">
                                    <?= htmlspecialchars($g['nama_guru']); ?> (<?= $g['nip']; ?>)
                                </option>
                                <?php endwhile; ?>
                            </select>
                            <div class="form-text">
                                <span class="badge bg-info"><?= $guru_belum_jadi_wali->num_rows; ?></span> guru tersedia
                            </div>
                        </div>

                        <div class="col-md-5">
                            <label class="form-label fw-bold">
                                <i class="bi bi-door-open"></i> Pilih Kelas
                            </label>
                            <select name="id_kelas" class="form-select" required>
                                <option value="">-- Pilih Kelas --</option>
                                <?php 
                                // Reset pointer
                                $kelas_tanpa_wali->data_seek(0);
                                while($k = $kelas_tanpa_wali->fetch_assoc()): 
                                ?>
                                <option value="<?= $k['id_kelas']; ?>">
                                    <?= htmlspecialchars($k['nama_kelas']); ?> (<?= $k['tingkat']; ?> - <?= $k['jurusan']; ?>)
                                </option>
                                <?php endwhile; ?>
                            </select>
                            <div class="form-text">
                                <span class="badge bg-info"><?= $kelas_tanpa_wali->num_rows; ?></span> kelas tersedia
                            </div>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label fw-bold">
                                <i class="bi bi-calendar"></i> Tahun Ajaran
                            </label>
                            <input type="text" name="tahun_ajaran" class="form-control"
                                   value="<?= date('Y'); ?>/<?= date('Y')+1; ?>" 
                                   required pattern="\d{4}/\d{4}" 
                                   title="Format: YYYY/YYYY (contoh: 2024/2025)">
                            <div class="form-text">Contoh: 2024/2025</div>
                        </div>

                        <div class="col-12 mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle me-2"></i> Tetapkan Wali Kelas
                            </button>
                            <button type="reset" class="btn btn-secondary">
                                <i class="bi bi-arrow-counterclockwise me-2"></i> Reset
                            </button>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TABEL DAFTAR WALI KELAS -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-table me-2"></i> Daftar Wali Kelas Aktif
                        </h5>
                        <span class="badge bg-primary"><?= $wali_kelas->num_rows; ?> Wali Kelas</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="20%">Kelas</th>
                                    <th width="25%">Wali Kelas</th>
                                    <th width="15%">NIP</th>
                                    <th width="15%">Tahun Ajaran</th>
                                    <th width="20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ($wali_kelas && $wali_kelas->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $wali_kelas->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($row['nama_kelas']); ?></strong>
                                        <br>
                                        <small class="text-muted"><?= $row['tingkat']; ?> - <?= $row['jurusan']; ?></small>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars($row['nama_guru']); ?>
                                        <br>
                                        <small class="text-muted">ID: <?= $row['id_guru']; ?></small>
                                    </td>
                                    <td><span class="badge bg-secondary"><?= $row['nip']; ?></span></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <i class="bi bi-calendar"></i> <?= $row['tahun_ajaran']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="?aksi=hapus&id=<?= $row['id_wali_kelas']; ?>"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('⚠️ Yakin ingin menghapus wali kelas:\n\nKelas: <?= addslashes($row['nama_kelas']); ?>\nWali: <?= addslashes($row['nama_guru']); ?>\n\nData yang dihapus tidak dapat dikembalikan!')">
                                            <i class="bi bi-trash me-1"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="bi bi-person-check display-1 text-muted"></i>
                                        <h5 class="mt-3 text-muted">Belum ada wali kelas</h5>
                                        <p class="text-muted">Tetapkan wali kelas menggunakan form di atas.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- INFORMASI TAMBAHAN -->
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Total Guru</h6>
                            <h3><?= $total_guru; ?> <small class="fs-6">guru</small></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Total Kelas</h6>
                            <h3><?= $total_kelas; ?> <small class="fs-6">kelas</small></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Wali Kelas Aktif</h6>
                            <h3><?= $total_wali; ?> <small class="fs-6">wali kelas</small></h3>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<?php 
// ================= TUTUP KONEKSI DI PALING AKHIR =================
$conn->close(); 
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script tambahan untuk validasi -->
<script>
// Validasi form sebelum submit
document.querySelector('form')?.addEventListener('submit', function(e) {
    let guru = this.querySelector('[name="id_guru"]')?.value;
    let kelas = this.querySelector('[name="id_kelas"]')?.value;
    let tahun = this.querySelector('[name="tahun_ajaran"]')?.value;
    
    if (!guru || !kelas || !tahun) {
        e.preventDefault();
        alert('Mohon lengkapi semua field yang diperlukan!');
        return false;
    }
    
    // Validasi format tahun ajaran
    let tahunPattern = /^\d{4}\/\d{4}$/;
    if (!tahunPattern.test(tahun)) {
        e.preventDefault();
        alert('Format tahun ajaran harus YYYY/YYYY (contoh: 2024/2025)');
        return false;
    }
    
    return true;
});
</script>

</body>
</html>