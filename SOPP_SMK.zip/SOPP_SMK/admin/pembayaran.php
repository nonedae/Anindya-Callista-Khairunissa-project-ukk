<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

$aksi = $_GET['aksi'] ?? '';
$id   = $_GET['id'] ?? 0;
$pesan = '';

// ================ HANDLE PENCARIAN & FILTER ================
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$filter_bulan = isset($_GET['filter_bulan']) ? $conn->real_escape_string($_GET['filter_bulan']) : '';
$filter_tahun = isset($_GET['filter_tahun']) ? $conn->real_escape_string($_GET['filter_tahun']) : '';
$filter_kelas = isset($_GET['filter_kelas']) ? (int)$_GET['filter_kelas'] : 0;

// ================ HAPUS PEMBAYARAN ================
if ($aksi == 'hapus' && $id > 0) {
    $conn->query("DELETE FROM pembayaran WHERE id_pembayaran = $id");
    $pesan = '<div class="alert alert-success">✅ Pembayaran berhasil dihapus!</div>';
}

// ================ QUERY DASAR ================
$sql = "
    SELECT p.*, s.nama_siswa, s.nisn, k.nama_kelas 
    FROM pembayaran p 
    JOIN siswa s ON p.id_siswa = s.id_siswa 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    WHERE 1=1
";

// ================ TAMBAHKAN FILTER ================
if (!empty($search)) {
    $sql .= " AND (s.nama_siswa LIKE '%$search%' 
               OR s.nisn LIKE '%$search%' 
               OR p.no_kwitansi LIKE '%$search%'
               OR k.nama_kelas LIKE '%$search%')";
}

if (!empty($filter_bulan)) {
    $sql .= " AND p.bulan = '$filter_bulan'";
}

if (!empty($filter_tahun)) {
    $sql .= " AND p.tahun = '$filter_tahun'";
}

if ($filter_kelas > 0) {
    $sql .= " AND s.id_kelas = $filter_kelas";
}

$sql .= " ORDER BY p.tanggal_bayar DESC, p.id_pembayaran DESC";
$pembayaran = $conn->query($sql);

// ================ AMBIL DATA UNTUK FILTER ================
$siswa = $conn->query("SELECT * FROM siswa ORDER BY nama_siswa");
$kelas = $conn->query("SELECT * FROM kelas ORDER BY nama_kelas");

$bulan_list = getBulanList();
$tahun_list = getTahunList();

// ================ TAMBAH PEMBAYARAN ================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah'])) {
    $id_siswa      = (int)$_POST['id_siswa'];
    $bulan         = $_POST['bulan'];
    $tahun         = $_POST['tahun'];
    $tanggal_bayar = $_POST['tanggal_bayar'];
    $no_kwitansi   = generateNoKwitansi();

    $cek = $conn->query("SELECT * FROM pembayaran 
                         WHERE id_siswa = $id_siswa 
                         AND bulan = '$bulan' AND tahun = '$tahun'");

    if ($cek->num_rows > 0) {
        $pesan = '<div class="alert alert-danger">❌ Siswa sudah membayar untuk bulan ini!</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO pembayaran 
            (id_siswa, bulan, tahun, jumlah, tanggal_bayar, no_kwitansi) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $jumlah = SOPP_BIAYA;
        $stmt->bind_param("issdss", $id_siswa, $bulan, $tahun, $jumlah, $tanggal_bayar, $no_kwitansi);

        if ($stmt->execute()) {
            $id_pembayaran = $stmt->insert_id;
            $pesan = '<div class="alert alert-success">
                        ✅ Pembayaran berhasil disimpan!
                        <a href="kwitansi.php?id='.$id_pembayaran.'" target="_blank" class="btn btn-sm btn-primary ms-2">
                        <i class="bi bi-printer"></i> Cetak Kwitansi</a>
                      </div>';
        }
        $stmt->close();
    }
}

// ================ AMBIL DATA UNTUK STATISTIK ================
$total_pembayaran = $conn->query("SELECT COUNT(*) as total FROM pembayaran")->fetch_assoc()['total'];
$total_nominal = $conn->query("SELECT SUM(jumlah) as total FROM pembayaran")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pembayaran SOPP - <?= APP_NAME ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .filter-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .table th {
            background-color: #f8f9fa;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- MAIN CONTENT -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <!-- HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3><i class="bi bi-cash-coin me-2"></i> Pembayaran SOPP</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Pembayaran</li>
                        </ol>
                    </nav>
                </div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahModal">
                    <i class="bi bi-plus-circle me-2"></i> Tambah Pembayaran
                </button>
            </div>

            <!-- STATISTIK CARD -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0 text-white-50">Total Pembayaran</h6>
                                <h2 class="mt-2 mb-0"><?= $total_pembayaran ?></h2>
                                <small class="text-white-50">Transaksi</small>
                            </div>
                            <i class="bi bi-cash-stack fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0 text-white-50">Total Nominal</h6>
                                <h2 class="mt-2 mb-0"><?= formatRupiah($total_nominal ?? 0) ?></h2>
                                <small class="text-white-50">Pendapatan</small>
                            </div>
                            <i class="bi bi-coin fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0 text-white-50">Biaya SOPP</h6>
                                <h2 class="mt-2 mb-0"><?= formatRupiah(SOPP_BIAYA) ?></h2>
                                <small class="text-white-50">Per Bulan</small>
                            </div>
                            <i class="bi bi-tag fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PESAN NOTIFIKASI -->
            <?= $pesan ?>

            <!-- FILTER & PENCARIAN -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-funnel me-2"></i> Filter & Pencarian</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <!-- Baris 1: Pencarian -->
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">
                                <i class="bi bi-search"></i> Pencarian
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Cari berdasarkan Nama Siswa, NISN, No. Kwitansi, atau Kelas..." 
                                       value="<?= htmlspecialchars($search) ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="bi bi-search"></i> Cari
                                </button>
                                <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun) || $filter_kelas > 0): ?>
                                <a href="pembayaran.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Reset
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Baris 2: Filter -->
                        <div class="col-md-3">
                            <label class="form-label">Filter Bulan</label>
                            <select class="form-select" name="filter_bulan" onchange="this.form.submit()">
                                <option value="">-- Semua Bulan --</option>
                                <?php foreach($bulan_list as $bulan): ?>
                                <option value="<?= $bulan ?>" <?= $filter_bulan == $bulan ? 'selected' : '' ?>>
                                    <?= $bulan ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Filter Tahun</label>
                            <select class="form-select" name="filter_tahun" onchange="this.form.submit()">
                                <option value="">-- Semua Tahun --</option>
                                <?php foreach($tahun_list as $tahun): ?>
                                <option value="<?= $tahun ?>" <?= $filter_tahun == $tahun ? 'selected' : '' ?>>
                                    <?= $tahun ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Filter Kelas</label>
                            <select class="form-select" name="filter_kelas" onchange="this.form.submit()">
                                <option value="">-- Semua Kelas --</option>
                                <?php 
                                $kelas_filter = $conn->query("SELECT * FROM kelas ORDER BY nama_kelas");
                                while($k = $kelas_filter->fetch_assoc()): 
                                ?>
                                <option value="<?= $k['id_kelas'] ?>" <?= $filter_kelas == $k['id_kelas'] ? 'selected' : '' ?>>
                                    <?= $k['nama_kelas'] ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Informasi</label>
                            <div class="form-control bg-light">
                                <i class="bi bi-info-circle"></i> 
                                Ditemukan: <strong><?= $pembayaran->num_rows ?></strong> data
                                <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun) || $filter_kelas > 0): ?>
                                    <span class="badge bg-info ms-2">Filter Aktif</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- TABEL PEMBAYARAN -->
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-table me-2"></i> Daftar Pembayaran SOPP
                    </h5>
                    <span class="badge bg-primary"><?= $pembayaran->num_rows ?> Transaksi</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="15%">Siswa</th>
                                    <th width="10%">NISN</th>
                                    <th width="10%">Kelas</th>
                                    <th width="12%">Bulan/Tahun</th>
                                    <th width="12%">Jumlah</th>
                                    <th width="10%">Tanggal Bayar</th>
                                    <th width="15%">No Kwitansi</th>
                                    <th width="11%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ($pembayaran && $pembayaran->num_rows > 0): ?>
                                <?php $no = 1; ?>
                                <?php while($row = $pembayaran->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($row['nama_siswa']) ?></strong>
                                    </td>
                                    <td><span class="badge bg-secondary"><?= $row['nisn'] ?></span></td>
                                    <td><?= htmlspecialchars($row['nama_kelas']) ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?= $row['bulan'] ?> <?= $row['tahun'] ?>
                                        </span>
                                    </td>
                                    <td class="fw-bold text-primary"><?= formatRupiah($row['jumlah']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_bayar'])) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark" style="font-family: monospace;">
                                            <?= $row['no_kwitansi'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="kwitansi.php?id=<?= $row['id_pembayaran'] ?>" 
                                               target="_blank" 
                                               class="btn btn-success" 
                                               title="Cetak Kwitansi">
                                                <i class="bi bi-printer"></i>
                                            </a>
                                            <a href="?aksi=hapus&id=<?= $row['id_pembayaran'] ?>" 
                                               class="btn btn-danger"
                                               onclick="return confirm('⚠️ Yakin ingin menghapus pembayaran ini?\n\nSiswa: <?= addslashes($row['nama_siswa']) ?>\nBulan: <?= $row['bulan'] ?> <?= $row['tahun'] ?>\nNominal: <?= formatRupiah($row['jumlah']) ?>\n\nData yang dihapus tidak dapat dikembalikan!')"
                                               title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5">
                                        <i class="bi bi-cash-coin display-1 text-muted"></i>
                                        <h5 class="mt-3 text-muted">
                                            <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun) || $filter_kelas > 0): ?>
                                                Tidak ditemukan data pembayaran dengan filter yang dipilih
                                            <?php else: ?>
                                                Belum ada data pembayaran
                                            <?php endif; ?>
                                        </h5>
                                        <?php if (!empty($search) || !empty($filter_bulan) || !empty($filter_tahun) || $filter_kelas > 0): ?>
                                        <a href="pembayaran.php" class="btn btn-outline-primary mt-3">
                                            <i class="bi bi-arrow-left"></i> Tampilkan semua data
                                        </a>
                                        <?php else: ?>
                                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#tambahModal">
                                            <i class="bi bi-plus-circle"></i> Tambah Pembayaran Pertama
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- INFORMASI TAMBAHAN -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">
                                <i class="bi bi-info-circle"></i> Informasi
                            </h6>
                            <ul class="mb-0 small">
                                <li class="mb-1">Kwitansi dapat dicetak ulang kapan saja</li>
                                <li class="mb-1">Siswa hanya dapat membayar 1 kali per bulan</li>
                                <li class="mb-1">Biaya SOPP: <?= formatRupiah(SOPP_BIAYA) ?> per bulan</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">
                                <i class="bi bi-tag"></i> Tahun Ajaran
                            </h6>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach($tahun_list as $th): ?>
                                <span class="badge bg-secondary"><?= $th ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- MODAL TAMBAH PEMBAYARAN -->
<div class="modal fade" id="tambahModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle me-2"></i> Tambah Pembayaran Baru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Pilih Siswa <span class="text-danger">*</span></label>
                        <select class="form-select" name="id_siswa" required>
                            <option value="">-- Pilih Siswa --</option>
                            <?php 
                            $siswa_modal = $conn->query("
                                SELECT s.*, k.nama_kelas 
                                FROM siswa s 
                                JOIN kelas k ON s.id_kelas = k.id_kelas 
                                ORDER BY s.nama_siswa
                            ");
                            while($s = $siswa_modal->fetch_assoc()): 
                            ?>
                            <option value="<?= $s['id_siswa'] ?>">
                                <?= htmlspecialchars($s['nama_siswa']) ?> 
                                (Kelas: <?= $s['nama_kelas'] ?> - NISN: <?= $s['nisn'] ?>)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Bulan <span class="text-danger">*</span></label>
                            <select class="form-select" name="bulan" required>
                                <option value="">-- Pilih Bulan --</option>
                                <?php foreach($bulan_list as $bulan): ?>
                                <option value="<?= $bulan ?>"><?= $bulan ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Tahun <span class="text-danger">*</span></label>
                            <select class="form-select" name="tahun" required>
                                <option value="">-- Pilih Tahun --</option>
                                <?php foreach($tahun_list as $tahun): ?>
                                <option value="<?= $tahun ?>" <?= $tahun == date('Y') ? 'selected' : '' ?>>
                                    <?= $tahun ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Tanggal Bayar <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="tanggal_bayar" 
                               value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="alert alert-info mb-0">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-info-circle fs-4 me-2"></i>
                            <div>
                                <strong>Biaya SOPP:</strong> <?= formatRupiah(SOPP_BIAYA) ?> per bulan<br>
                                <small class="text-muted">Nomor kwitansi akan dibuat otomatis oleh sistem.</small>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x"></i> Batal
                    </button>
                    <button type="submit" name="tambah" class="btn btn-primary">
                        <i class="bi bi-save"></i> Simpan Pembayaran
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php 
// ================ TUTUP KONEKSI ================
$conn->close(); 
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script tambahan untuk filter -->
<script>
// Auto submit saat memilih filter
document.querySelectorAll('select[name="filter_bulan"], select[name="filter_tahun"], select[name="filter_kelas"]').forEach(select => {
    select.addEventListener('change', function() {
        this.form.submit();
    });
});

// Konfirmasi hapus dengan detail
document.querySelectorAll('.btn-danger[onclick]').forEach(btn => {
    btn.addEventListener('click', function(e) {
        if (!confirm(this.getAttribute('onclick')?.replace('return confirm(', '').replace(')', ''))) {
            e.preventDefault();
        }
    });
});
</script>

</body>
</html>