<?php
require_once '../config/database.php';
cekRole(['admin']);

$conn = koneksiDB();

$pesan = '';
$aksi = $_GET['aksi'] ?? '';
$id   = (int)($_GET['id'] ?? 0);

// ================= HAPUS KELAS =================
if ($aksi === 'hapus' && $id > 0) {
    $cek = $conn->query("SELECT id_siswa FROM siswa WHERE id_kelas = $id");
    if ($cek->num_rows > 0) {
        $pesan = '<div class="alert alert-danger">Kelas masih memiliki siswa, tidak bisa dihapus!</div>';
    } else {
        $conn->query("DELETE FROM kelas WHERE id_kelas = $id");
        $pesan = '<div class="alert alert-success">Data kelas berhasil dihapus!</div>';
    }
}

// ================= TAMBAH / EDIT =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_kelas   = (int)($_POST['id_kelas'] ?? 0);
    $nama_kelas = $_POST['nama_kelas'];
    $tingkat    = $_POST['tingkat'];
    $jurusan    = $_POST['jurusan'] ?? '';

    if ($id_kelas > 0) {
        $stmt = $conn->prepare("UPDATE kelas SET nama_kelas=?, tingkat=?, jurusan=? WHERE id_kelas=?");
        $stmt->bind_param("sssi", $nama_kelas, $tingkat, $jurusan, $id_kelas);
    } else {
        $cek = $conn->prepare("SELECT id_kelas FROM kelas WHERE nama_kelas=?");
        $cek->bind_param("s", $nama_kelas);
        $cek->execute();
        $cek->store_result();

        if ($cek->num_rows > 0) {
            $pesan = '<div class="alert alert-danger">Nama kelas sudah ada!</div>';
        } else {
            $stmt = $conn->prepare("INSERT INTO kelas (nama_kelas, tingkat, jurusan) VALUES (?,?,?)");
            $stmt->bind_param("sss", $nama_kelas, $tingkat, $jurusan);
        }
        $cek->close();
    }

    if (isset($stmt) && $stmt->execute()) {
        $pesan = '<div class="alert alert-success">Data kelas berhasil disimpan!</div>';
    }
    if (isset($stmt)) $stmt->close();
}

// ================= DATA KELAS =================
$kelas = $conn->query("
    SELECT k.*, COUNT(s.id_siswa) AS jumlah_siswa
    FROM kelas k
    LEFT JOIN siswa s ON k.id_kelas = s.id_kelas
    GROUP BY k.id_kelas
    ORDER BY k.tingkat, k.nama_kelas
");

$kelas_edit = null;
if ($aksi === 'edit' && $id > 0) {
    $kelas_edit = $conn->query("SELECT * FROM kelas WHERE id_kelas = $id")->fetch_assoc();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Kelas - <?= APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>

<body>
<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- MAIN CONTENT -->
        <main class="col-md-10 ms-sm-auto px-4 py-4">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3><i class="bi bi-building"></i> Data Kelas</h3>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kelasModal">
                    <i class="bi bi-plus-circle"></i> Tambah Kelas
                </button>
            </div>

            <?= $pesan; ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Kelas</th>
                                    <th>Tingkat</th>
                                    <th>Jurusan</th>
                                    <th>Jumlah Siswa</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ($kelas->num_rows > 0): ?>
                                <?php $no = 1; while($row = $kelas->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><strong><?= $row['nama_kelas']; ?></strong></td>
                                    <td><span class="badge bg-primary"><?= $row['tingkat']; ?></span></td>
                                    <td><?= $row['jurusan'] ?: '-'; ?></td>
                                    <td><span class="badge bg-info"><?= $row['jumlah_siswa']; ?> siswa</span></td>
                                    <td>
                                        <a href="siswa.php?kelas=<?= $row['id_kelas']; ?>" class="btn btn-sm btn-info">
                                            <i class="bi bi-people"></i>
                                        </a>
                                        <a href="?aksi=edit&id=<?= $row['id_kelas']; ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="?aksi=hapus&id=<?= $row['id_kelas']; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Hapus kelas ini?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="bi bi-building display-4 text-muted"></i>
                                        <h5 class="mt-3 text-muted">Belum ada data kelas</h5>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="kelasModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="bi bi-building"></i>
                        <?= $kelas_edit ? 'Edit' : 'Tambah'; ?> Data Kelas
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="id_kelas" value="<?= $kelas_edit['id_kelas'] ?? ''; ?>">

                    <div class="mb-3">
                        <label class="form-label">Nama Kelas</label>
                        <input type="text" name="nama_kelas" class="form-control" required
                               value="<?= $kelas_edit['nama_kelas'] ?? ''; ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tingkat</label>
                            <select name="tingkat" class="form-select" required>
                                <option value="">-- Pilih --</option>
                                <option value="X"  <?= ($kelas_edit['tingkat'] ?? '')=='X'?'selected':''; ?>>X</option>
                                <option value="XI" <?= ($kelas_edit['tingkat'] ?? '')=='XI'?'selected':''; ?>>XI</option>
                                <option value="XII"<?= ($kelas_edit['tingkat'] ?? '')=='XII'?'selected':''; ?>>XII</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jurusan</label>
                            <input type="text" name="jurusan" class="form-control"
                                   value="<?= $kelas_edit['jurusan'] ?? ''; ?>">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<?php if ($kelas_edit): ?>
<script>
    var myModal = new bootstrap.Modal(document.getElementById('kelasModal'));
    myModal.show();
</script>
<?php endif; ?>

</body>
</html>