<?php
require_once '../config/database.php';
cekRole(['siswa']);

$conn = koneksiDB();
$username = $_SESSION['username'];

// Ambil data siswa menggunakan prepared statement
$stmt = $conn->prepare("
    SELECT s.*, k.nama_kelas 
    FROM siswa s 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    WHERE s.nisn = ?
");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$siswa = $result->fetch_assoc();
$stmt->close();

if (!$siswa) {
    die("Data siswa tidak ditemukan! Hubungi admin.");
}

$id_siswa = $siswa['id_siswa'];
$nisn = $siswa['nisn'];
$nama_siswa = $siswa['nama_siswa'];

// Definisikan biaya SOPP jika belum ada
if (!defined('SOPP_BIAYA')) {
    define('SOPP_BIAYA', 50000);
}

// Ambil semua data pembayaran siswa
$pembayaran = [];
$stmt = $conn->prepare("
    SELECT * FROM pembayaran 
    WHERE id_siswa = ? 
    ORDER BY tahun DESC, 
    FIELD(bulan, 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember')
");
$stmt->bind_param("i", $id_siswa);
$stmt->execute();
$result = $stmt->get_result();
while($row = $result->fetch_assoc()) {
    $pembayaran[] = $row;
}
$stmt->close();

// Hitung bulan sudah bayar dan belum bayar untuk tahun ini
$tahun_ini = date('Y');
$bulan_ini = date('n');
$bulan_list = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

$sudah_bayar = [];
$belum_bayar = [];

foreach ($bulan_list as $index => $bulan) {
    $cek = $conn->query("SELECT * FROM pembayaran WHERE id_siswa = $id_siswa AND bulan = '$bulan' AND tahun = '$tahun_ini'");
    if ($cek->num_rows > 0) {
        $sudah_bayar[] = $bulan;
    } else {
        if ($index + 1 <= $bulan_ini) {
            $belum_bayar[] = $bulan;
        }
    }
}

$conn->close();

// Fungsi untuk mendapatkan warna badge berdasarkan status
function getStatusBadge($status) {
    switch($status) {
        case 'lunas':
            return '<span class="badge-status lunas"><i class="bi bi-check-circle"></i> LUNAS</span>';
        case 'pending':
            return '<span class="badge-status pending"><i class="bi bi-clock"></i> PENDING</span>';
        case 'batal':
            return '<span class="badge-status batal"><i class="bi bi-x-circle"></i> BATAL</span>';
        default:
            return '<span class="badge-status">' . $status . '</span>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pembayaran SOPP - <?php echo defined('APP_NAME') ? APP_NAME : 'SOPP SMK'; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Roboto, sans-serif;
            padding: 20px;
        }
        /* Navbar Style */
        .navbar-custom {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 10px 20px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .navbar-custom .navbar-brand {
            color: #764ba2;
            font-weight: 700;
        }
        .navbar-custom .nav-link {
            color: #495057;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .navbar-custom .nav-link:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .navbar-custom .nav-link i {
            margin-right: 5px;
        }
        .user-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
        }
        .user-info i {
            margin-right: 5px;
        }
        .container-custom { 
            max-width: 1200px; 
            margin: 0 auto; 
        }
        .card-custom {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
        }
        .info-card h5 {
            margin-bottom: 5px;
            font-size: 1.1rem;
            opacity: 0.9;
        }
        .info-card h3 {
            margin-bottom: 0;
            font-weight: 700;
        }
        .status-card {
            border-radius: 15px;
            padding: 20px;
            height: 100%;
            border: none;
        }
        .status-card.sudah-bayar {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        .status-card.belum-bayar {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            color: white;
        }
        .status-card .card-title {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 15px;
        }
        .status-card .card-value {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .bulan-container {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 15px;
        }
        .bulan-badge {
            padding: 8px 15px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
        }
        .bulan-badge.sudah {
            background: rgba(255,255,255,0.25);
            color: white;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .bulan-badge.sudah i {
            margin-right: 5px;
        }
        .bulan-badge.belum {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px dashed rgba(255,255,255,0.5);
        }
        .table-custom {
            border-radius: 15px;
            overflow: hidden;
        }
        .table-custom thead {
            background: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
        .table-custom th {
            padding: 15px;
            font-weight: 600;
            color: #495057;
        }
        .table-custom td {
            padding: 15px;
            vertical-align: middle;
        }
        .badge-status {
            padding: 8px 15px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
        }
        .badge-status.lunas {
            background: #d4edda;
            color: #155724;
        }
        .badge-status.pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-status.batal {
            background: #f8d7da;
            color: #721c24;
        }
        .total-box {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }
        .total-box .label {
            color: #6c757d;
            margin-bottom: 5px;
        }
        .total-box .value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #28a745;
        }
        .empty-state {
            text-align: center;
            padding: 50px 20px;
        }
        .empty-state i {
            font-size: 5rem;
            color: #dee2e6;
            margin-bottom: 20px;
        }
        .empty-state h4 {
            color: #6c757d;
            margin-bottom: 10px;
        }
        .empty-state p {
            color: #adb5bd;
        }
        .breadcrumb-custom {
            background: rgba(255,255,255,0.2);
            padding: 10px 20px;
            border-radius: 50px;
            margin-bottom: 25px;
            color: white;
        }
        .breadcrumb-custom a {
            color: white;
            text-decoration: none;
            opacity: 0.8;
        }
        .breadcrumb-custom a:hover {
            opacity: 1;
        }
    </style>
</head>
<body>
    <!-- Navbar langsung di file -->
    <div class="container-custom">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="dashboard.php">
                    <i class="bi bi-cash-coin me-2"></i>
                    <strong>SOPP</strong> SMKN 1 Dlanggu
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="bi bi-house-door"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="pembayaran.php">
                                <i class="bi bi-cash-coin"></i> Pembayaran
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="user-info ms-2">
                                <i class="bi bi-person-circle"></i> 
                                <?php echo htmlspecialchars($nama_siswa); ?> (<?php echo $siswa['nama_kelas']; ?>)
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="../logout.php">
                                <i class="bi bi-box-arrow-right"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Breadcrumb -->
        <div class="breadcrumb-custom">
            <i class="bi bi-house-door me-2"></i>
            <a href="dashboard.php">Dashboard</a> / 
            <span>Pembayaran</span>
        </div>
        
        <!-- Info Siswa -->
        <div class="info-card">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <h5>Nama Siswa</h5>
                    <h3><?php echo htmlspecialchars($nama_siswa); ?></h3>
                </div>
                <div class="col-md-3">
                    <h5>Kelas</h5>
                    <h3><?php echo htmlspecialchars($siswa['nama_kelas']); ?></h3>
                </div>
                <div class="col-md-3">
                    <h5>NISN</h5>
                    <h3><?php echo $nisn; ?></h3>
                </div>
                <div class="col-md-2">
                    <h5>Total Bayar</h5>
                    <h3><?php echo count($pembayaran); ?>x</h3>
                </div>
            </div>
        </div>
        
        <!-- Status Pembayaran Tahun Ini -->
        <div class="row mb-4">
            <div class="col-md-6 mb-3 mb-md-0">
                <div class="status-card sudah-bayar">
                    <div class="card-title">
                        <i class="bi bi-check-circle-fill"></i> SUDAH BAYAR TAHUN <?php echo $tahun_ini; ?>
                    </div>
                    <div class="card-value"><?php echo count($sudah_bayar); ?> Bulan</div>
                    <div class="bulan-container">
                        <?php if (count($sudah_bayar) > 0): ?>
                            <?php foreach($sudah_bayar as $bulan): ?>
                                <span class="bulan-badge sudah">
                                    <i class="bi bi-check-circle-fill"></i> <?php echo $bulan; ?>
                                </span>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="mb-0 opacity-75">Belum ada pembayaran tahun ini</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="status-card belum-bayar">
                    <div class="card-title">
                        <i class="bi bi-exclamation-triangle-fill"></i> BELUM BAYAR TAHUN <?php echo $tahun_ini; ?>
                    </div>
                    <div class="card-value"><?php echo count($belum_bayar); ?> Bulan</div>
                    <div class="bulan-container">
                        <?php if (count($belum_bayar) > 0): ?>
                            <?php foreach($belum_bayar as $bulan): ?>
                                <span class="bulan-badge belum">
                                    <i class="bi bi-exclamation-circle"></i> <?php echo $bulan; ?>
                                </span>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="mb-0 opacity-75">LUNAS! Semua sudah dibayar</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Statistik Pembayaran -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="total-box">
                    <div class="label">Total Dibayar</div>
                    <div class="value"><?php echo count($pembayaran); ?> Bulan</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="total-box">
                    <div class="label">Total Nominal</div>
                    <div class="value"><?php echo formatRupiah(count($pembayaran) * SOPP_BIAYA); ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="total-box">
                    <div class="label">Sudah Bayar (<?php echo $tahun_ini; ?>)</div>
                    <div class="value text-success"><?php echo count($sudah_bayar); ?> Bulan</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="total-box">
                    <div class="label">Belum Bayar (<?php echo $tahun_ini; ?>)</div>
                    <div class="value text-warning"><?php echo count($belum_bayar); ?> Bulan</div>
                </div>
            </div>
        </div>
        
        <!-- Tabel Riwayat Pembayaran -->
        <div class="card-custom">
            <h4 class="mb-4"><i class="bi bi-clock-history me-2"></i>Riwayat Pembayaran</h4>
            
            <?php if (!empty($pembayaran)): ?>
                <div class="table-responsive">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Bulan</th>
                                <th>Tahun</th>
                                <th>Jumlah</th>
                                <th>Tanggal Bayar</th>
                                <th>Status</th>
                                <th>No. Kwitansi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($pembayaran as $index => $bayar): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><strong><?php echo htmlspecialchars($bayar['bulan']); ?></strong></td>
                                <td><?php echo $bayar['tahun']; ?></td>
                                <td><?php echo formatRupiah($bayar['jumlah']); ?></td>
                                <td>
                                    <?php 
                                    if ($bayar['tanggal_bayar']) {
                                        echo date('d/m/Y H:i', strtotime($bayar['tanggal_bayar']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?php echo getStatusBadge($bayar['status']); ?></td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <i class="bi bi-receipt"></i> 
                                        <?php echo $bayar['no_kwitansi'] ?? 'KW-' . str_pad($bayar['id_pembayaran'], 4, '0', STR_PAD_LEFT); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="bi bi-credit-card"></i>
                    <h4>Belum Ada Riwayat Pembayaran</h4>
                    <p class="text-muted">Anda belum melakukan pembayaran SOPP</p>
                </div>
            <?php endif; ?>
            
            <!-- Informasi Pembayaran -->
            <div class="alert alert-info mt-4">
                <div class="d-flex">
                    <i class="bi bi-info-circle-fill me-3 fs-4"></i>
                    <div>
                        <h6 class="alert-heading fw-bold">Informasi Pembayaran</h6>
                        <p class="mb-0">
                            <strong>Biaya SOPP:</strong> <?php echo formatRupiah(SOPP_BIAYA); ?> per bulan<br>
                            <strong>Pembayaran:</strong> Melalui Tata Usaha SMKN 1 Dlanggu<br>
                            <strong>Keterangan:</strong> Untuk informasi lebih lanjut hubungi bagian TU
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>