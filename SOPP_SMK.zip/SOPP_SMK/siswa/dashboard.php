<?php
require_once '../config/database.php';
cekRole(['siswa']);

$conn = koneksiDB();

// ============ PERBAIKAN: Ambil data siswa berdasarkan NISN (username) ============
$username = $_SESSION['username']; // Username = NISN

// Get siswa data berdasarkan NISN
$siswa = $conn->query("
    SELECT s.*, k.nama_kelas 
    FROM siswa s 
    JOIN kelas k ON s.id_kelas = k.id_kelas 
    WHERE s.nisn = '$username'
")->fetch_assoc();

if (!$siswa) {
    // Coba cari berdasarkan user_id jika ada
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $siswa = $conn->query("
            SELECT s.*, k.nama_kelas 
            FROM users u
            JOIN siswa s ON u.id_siswa = s.id_siswa
            JOIN kelas k ON s.id_kelas = k.id_kelas 
            WHERE u.id_user = $user_id
        ")->fetch_assoc();
    }
}

if (!$siswa) {
    die("
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 30px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 8px; text-align: center;'>
        <i class='bi bi-exclamation-triangle' style='font-size: 48px; color: #856404;'></i>
        <h2 style='color: #856404; margin-top: 20px;'>Data Siswa Tidak Ditemukan!</h2>
        <p style='margin-bottom: 25px; color: #856404;'>Akun Anda belum terhubung dengan data siswa.</p>
        <a href='../logout.php' class='btn btn-danger'>Logout</a>
    </div>
    ");
}

$id_siswa = $siswa['id_siswa'];

// Get payment history
$riwayat = $conn->query("
    SELECT * FROM pembayaran 
    WHERE id_siswa = $id_siswa 
    ORDER BY tahun DESC, 
    FIELD(bulan, 
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ) DESC
");

// Get paid and unpaid months this year
$tahun_ini = date('Y');
$bulan_ini = date('n');
$bulan_list = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

$sudah_bayar = [];
$belum_bayar = [];

foreach ($bulan_list as $index => $bulan) {
    $cek = $conn->query("SELECT * FROM pembayaran WHERE id_siswa = $id_siswa AND bulan = '$bulan' AND tahun = '$tahun_ini'");
    if ($cek->num_rows > 0) {
        $sudah_bayar[] = $bulan;
    } else {
        if ($index + 1 <= $bulan_ini) {
            $belum_bayar[] = $bulan;
        }
    }
}

$conn->close();

// Fungsi format rupiah jika belum ada
if (!function_exists('formatRupiah')) {
    function formatRupiah($angka) {
        return 'Rp ' . number_format($angka, 0, ',', '.');
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Siswa - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        }
        .navbar-brand, .navbar .btn-outline-primary {
            color: white !important;
            border-color: white !important;
        }
        .navbar .btn-outline-primary:hover {
            background: white !important;
            color: #764ba2 !important;
        }
        .badge.bg-info {
            background: rgba(255,255,255,0.2) !important;
            color: white !important;
            padding: 8px 15px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card-header {
            border-radius: 15px 15px 0 0 !important;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 20px;
        }
        .card-header.bg-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
        }
        .card-header.bg-warning {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%) !important;
        }
        .bg-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            border-radius: 15px;
        }
        .badge {
            padding: 8px 15px;
            border-radius: 50px;
            font-weight: 500;
        }
        .badge.bg-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
        }
        .badge.bg-warning {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%) !important;
            color: #000 !important;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 8px 20px;
            border-radius: 50px;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .table thead th {
            background: #f8f9fa;
            color: #495057;
            font-weight: 600;
            border-bottom: none;
        }
        .dropdown-menu {
            border: none;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        .dropdown-item {
            padding: 10px 20px;
            border-radius: 8px;
            margin: 5px;
        }
        .dropdown-item:hover {
            background: #f8f9fa;
        }
        /* Style untuk tampilan kwitansi */
        .kwitansi-badge {
            background: #e9ecef;
            color: #495057;
            padding: 5px 10px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="bi bi-cash-coin"></i>
                <span class="fw-bold">SOPP</span>
                <small class="opacity-75">SMKN 1 DLANGGU</small>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="badge bg-info me-3">
                    <i class="bi bi-mortarboard"></i> <?php echo $siswa['nama_kelas']; ?>
                </span>
                <div class="dropdown">
                    <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo $siswa['nama_siswa']; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-house"></i> Dashboard</a></li>
                        <li><a class="dropdown-item" href="pembayaran.php"><i class="bi bi-cash-coin"></i> Pembayaran</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- Header Siswa -->
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4><i class="bi bi-person-circle"></i> Selamat Datang, <?php echo $siswa['nama_siswa']; ?>!</h4>
                        <p class="mb-1">
                            <i class="bi bi-mortarboard"></i> Kelas: <?php echo $siswa['nama_kelas']; ?> | 
                            <i class="bi bi-person-badge"></i> NISN: <?php echo $siswa['nisn']; ?>
                        </p>
                        <p class="mb-0">
                            <i class="bi bi-info-circle"></i> Sistem Pembayaran SOPP
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <i class="bi bi-person-circle display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Status Pembayaran -->
        <div class="row mb-4">
            <div class="col-md-6 mb-3 mb-md-0">
                <div class="card h-100">
                    <div class="card-header bg-success">
                        <h5 class="mb-0"><i class="bi bi-check-circle"></i> Sudah Bayar (<?php echo $tahun_ini; ?>)</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($sudah_bayar) > 0): ?>
                            <div class="d-flex flex-wrap gap-2 mb-3">
                                <?php foreach($sudah_bayar as $bulan): ?>
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle-fill me-1"></i><?php echo $bulan; ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <div class="border-top pt-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Total Bulan:</span>
                                    <span class="h5 mb-0 text-success fw-bold"><?php echo count($sudah_bayar); ?> bulan</span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="bi bi-cash-coin display-4 text-muted"></i>
                                <p class="mt-3 text-muted">Belum ada pembayaran tahun ini</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0 text-dark"><i class="bi bi-exclamation-triangle"></i> Belum Bayar (<?php echo $tahun_ini; ?>)</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($belum_bayar) > 0): ?>
                            <div class="d-flex flex-wrap gap-2 mb-3">
                                <?php foreach($belum_bayar as $bulan): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="bi bi-exclamation-circle-fill me-1"></i><?php echo $bulan; ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <div class="border-top pt-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Total Bulan:</span>
                                    <span class="h5 mb-0 text-warning fw-bold"><?php echo count($belum_bayar); ?> bulan</span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="bi bi-check-circle display-4 text-success"></i>
                                <p class="mt-3 text-success fw-bold">LUNAS! Semua sudah dibayar.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Riwayat Pembayaran -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-clock-history"></i> Riwayat Pembayaran</h5>
            </div>
            <div class="card-body">
                <?php if ($riwayat->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="25%">Bulan/Tahun</th>
                                    <th width="20%">Jumlah</th>
                                    <th width="20%">Tanggal Bayar</th>
                                    <th width="30%">No Kwitansi</th>
                                    <!-- KOLOM AKSI DIHAPUS -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php while($row = $riwayat->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td>
                                        <span class="fw-bold"><?php echo $row['bulan'] . ' ' . $row['tahun']; ?></span>
                                    </td>
                                    <td>
                                        <span class="text-success fw-bold"><?php echo formatRupiah($row['jumlah']); ?></span>
                                    </td>
                                    <td>
                                        <i class="bi bi-calendar3 me-1"></i>
                                        <?php echo date('d/m/Y', strtotime($row['tanggal_bayar'])); ?>
                                    </td>
                                    <td>
                                        <span class="kwitansi-badge">
                                            <i class="bi bi-receipt"></i> 
                                            <?php echo $row['no_kwitansi'] ?? 'KW-' . str_pad($row['id_pembayaran'], 4, '0', STR_PAD_LEFT); ?>
                                        </span>
                                    </td>
                                    <!-- TOMBOL CETAK DIHAPUS -->
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-cash-coin display-4 text-muted"></i>
                        <h5 class="mt-3 text-muted">Belum ada riwayat pembayaran</h5>
                        <p class="text-muted">Anda belum melakukan pembayaran SOPP</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Info SOPP -->
        <div class="card mt-4 mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h5 class="text-primary mb-3">
                            <i class="bi bi-info-circle-fill"></i> Informasi SOPP
                        </h5>
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                Biaya SOPP: <span class="fw-bold">Rp 200.000 per bulan</span>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-calendar-check text-primary me-2"></i>
                                Batas pembayaran: <span class="fw-bold">Tanggal 10 setiap bulan</span>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-info-circle text-info me-2"></i>
                                Tidak ada sanksi keterlambatan (sifatnya sumbangan)
                            </li>
                            <li>
                                <i class="bi bi-person-badge text-warning me-2"></i>
                                Hubungi wali kelas untuk informasi lebih lanjut
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 text-center">
                        <i class="bi bi-cash-stack display-4 text-primary opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>